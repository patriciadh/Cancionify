﻿Public Class Album

    Public Property IDAlbum As Integer
    Public Property NombreAlbum As String
    Public Property FechaAlbum As Date
    Public Property ArtistaAlbum As String
    Public Property DuracionAlbum As Integer
    Public Property Portada As String
    Public ReadOnly Property AlbDAO As AlbumDAO
    Public Sub New()
        Me.AlbDAO = New AlbumDAO
    End Sub

    Public Sub New(NombreAlbum As String)
        Me.AlbDAO = New AlbumDAO
        Me.NombreAlbum = NombreAlbum
    End Sub
    Public Sub New(IDAlbum As Integer)
        Me.AlbDAO = New AlbumDAO
        Me.IDAlbum = IDAlbum
    End Sub
    Public Sub LeerTodosAlbumes()
        Me.AlbDAO.LeerTodos()
    End Sub

    Public Sub LeerAlbum()
        Me.AlbDAO.Leer(Me)
    End Sub

    Public Sub LeerNombreAlbum(artista As Artista)
        Me.AlbDAO.LeerAlbumes(artista)
    End Sub

    Public Sub LeerDuracionAlbum()
        Me.AlbDAO.LeerDuracion(Me)
    End Sub

    Public Sub LeerNombreAlbum2()
        Me.AlbDAO.LeerAlbum2(Me)
    End Sub

    Public Function InsertarAlbum() As Integer
        Me.DuracionAlbum = 0
        Return Me.AlbDAO.Insertar(Me)
    End Function

    Public Function ActualizarAlbum() As Integer
        Return Me.AlbDAO.Actualizar(Me)
    End Function

    Public Function BorrarAlbum() As Integer
        Return Me.AlbDAO.Borrar(Me)
    End Function
End Class
