﻿Public Class Artista

    Public Property IDArtista As Integer
    Public Property NombreArtista As String
    Public Property PaisArtista As String
    Public Property EsFavorito As Boolean
    Public Property Imagen As String
    Public ReadOnly Property ArtDAO As ArtistaDAO

    Public Sub New(NombreArtista As String)
        Me.ArtDAO = New ArtistaDAO
        Me.NombreArtista = NombreArtista
    End Sub

    Public Sub New()
        Me.ArtDAO = New ArtistaDAO
    End Sub
    Public Sub New(IDArtista As Integer)
        Me.ArtDAO = New ArtistaDAO
        Me.IDArtista = IDArtista
    End Sub


    Public Function LeerFavorito(u As Usuario) As Boolean
        Return Me.ArtDAO.LeerFav(u, Me)
    End Function

    Public Sub LeerTodosArtistas()
        Me.ArtDAO.LeerTodos()
    End Sub

    Public Sub LeerArtista()
        Me.ArtDAO.Leer(Me)
    End Sub

    Public Sub LeerNombreArtista()
        Me.ArtDAO.LeerArtista(Me)
    End Sub

    Public Function InsertarArtista() As Integer
        Return Me.ArtDAO.Insertar(Me)
    End Function

    Public Function ActualizarArtista() As Integer
        Return Me.ArtDAO.Actualizar(Me)
    End Function

    Public Function BorrarArtista() As Integer
        Return Me.ArtDAO.Borrar(Me)
    End Function

    'ARTISTA FAVORITO
    Public Function InsertarArtistaFav(u As Usuario) As Integer
        Return Me.ArtDAO.InsertarFav(u, Me)
    End Function

    Public Function BorrarArtistaFav(u As Usuario) As Integer
        Return Me.ArtDAO.BorrarFav(u, Me)
    End Function

    ' CONSULTA 1
    Public Sub Consulta1(pais As String)
        Me.ArtDAO.Consulta1(pais)
    End Sub

    Public Sub Consulta1General()
        Me.ArtDAO.Consulta1General()
    End Sub

End Class
