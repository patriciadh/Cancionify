﻿Public Class Cancion
    Public Property IDCancion As Integer
    Public Property NombreCancion As String
    Public Property Album As String 'Como Album
    Public Property DuracionCancion As Integer
    Public ReadOnly Property CanDAO As CancionDAO

    Public Sub New()
        Me.CanDAO = New CancionDAO
    End Sub

    Public Sub New(NombreCancion As String)
        Me.CanDAO = New CancionDAO
        Me.NombreCancion = NombreCancion
    End Sub
    Public Sub New(IDCancion As Integer)
        Me.CanDAO = New CancionDAO
        Me.IDCancion = IDCancion
    End Sub

    Public Sub LeerTodasCancion()
        Me.CanDAO.LeerTodas()
    End Sub

    Public Sub LeerTodasReproducciones(usuario As Usuario)
        Me.CanDAO.LeerTodasReproducciones(usuario)
    End Sub

    Public Sub LeerCancion()
        Me.CanDAO.Leer(Me)
    End Sub

    Public Sub LeerNombreCancion(album As Album)
        Me.CanDAO.LeerCanciones(album)
    End Sub

    Public Sub LeerNombreCancion2()
        Me.CanDAO.LeerCancion2(Me)
    End Sub

    Public Function InsertarCancion() As Integer
        Return Me.CanDAO.Insertar(Me)
    End Function

    Public Function ActualizarCancion() As Integer
        Return Me.CanDAO.Actualizar(Me)
    End Function

    Public Function BorrarCancion() As Integer
        Return Me.CanDAO.Borrar(Me)
    End Function

    Public Function InsertarReproducciones(r As Reproduccion) As Integer
        Return Me.CanDAO.InsertarReproduccion(r)
    End Function

    ' CONSULTA 2
    Public Sub Consulta2()
        Me.CanDAO.Consulta2()
    End Sub
End Class
