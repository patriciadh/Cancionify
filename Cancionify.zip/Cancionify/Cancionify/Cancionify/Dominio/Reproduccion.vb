﻿Public Class Reproduccion
    Public Property IDReproduccion As Integer
    Public Property Usuario As String
    Public Property Cancion As Integer
    Public Property Fecha As Date
End Class
