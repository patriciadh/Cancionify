﻿Public Class Usuario
    Public Property Email As String
    Public Property Nombre As String
    Public Property Apellidos As String
    Public Property FechaNac As Date
    Public ReadOnly Property UsuDAO As UsuarioDAO

    Public Sub New()
        Me.UsuDAO = New UsuarioDAO
    End Sub

    Public Sub New(Email As String)
        Me.UsuDAO = New UsuarioDAO
        Me.Email = Email
    End Sub

    Public Sub LeerTodosUsuarios(ruta As String)
        Me.UsuDAO.LeerTodos(ruta)
    End Sub

    Public Sub LeerUsuario()
        Me.UsuDAO.Leer(Me)
    End Sub

    Public Function InsertarUsuario() As Integer
        Return Me.UsuDAO.Insertar(Me)
    End Function

    Public Function ActualizarUsuario() As Integer
        Return Me.UsuDAO.Actualizar(Me)
    End Function

    Public Function BorrarUsuario() As Integer
        Return Me.UsuDAO.Borrar(Me)
    End Function

    ' CONSULTA 3
    Public Sub Consulta3(fechaInicio As Date, fechaFin As Date)
        Me.UsuDAO.Consulta3(fechaInicio, fechaFin, Me)
    End Sub

    ' CONSULTA 4
    Public Sub Consulta4()
        Me.UsuDAO.Consulta4()
    End Sub

    ' CONSULTA 5
    Public Sub Consulta5()
        Me.UsuDAO.Consulta5(Me)
    End Sub

End Class
