﻿Public Class Agente
    Private Shared _instancia As Agente
    Private Shared conexion As OleDb.OleDbConnection
    Private Const cadenaConexionBase As String = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source="
    Private Shared cadenaConexion As String

    Private Sub New()
        Agente.conexion = New OleDb.OleDbConnection(Agente.cadenaConexion)
        Agente.conexion.Open()
    End Sub

    Public Shared Function ObtenerAgente() As Agente 'objeto singleton'
        If Agente._instancia Is Nothing Then
            Agente._instancia = New Agente
        End If
        Return Agente._instancia
    End Function

    Public Shared Function ObtenerAgente(ruta As String) As Agente
        Agente.cadenaConexion = Agente.cadenaConexionBase & ruta
        Return Agente.ObtenerAgente
    End Function

    Public Function Leer(sql As String) As Collection
        Dim result As New Collection
        Dim fila As Collection
        Dim i As Integer
        Dim reader As OleDb.OleDbDataReader 'Almacena toda la información de la consulta'
        Dim com As New OleDb.OleDbCommand(sql, Agente.conexion)
        Conectar()
        reader = com.ExecuteReader
        While reader.Read
            fila = New Collection
            For i = 0 To reader.FieldCount - 1
                fila.Add(reader(i).ToString) 'i número de columnas de las cuales queremos leer un valor'
            Next
            result.Add(fila)
        End While
        Desconectar()
        Return result
    End Function

    Public Function Modificar(sql As String) As Integer
        Dim com As New OleDb.OleDbCommand(sql, Agente.conexion)
        Dim result As Integer
        Conectar()
        result = com.ExecuteNonQuery 'Devuelve el número de filas afectadas'
        Desconectar()
        Return result
    End Function

    Private Sub Conectar()
        If Agente.conexion.State = ConnectionState.Closed Then
            Agente.conexion.Open()
        End If
    End Sub

    Private Sub Desconectar()
        If Agente.conexion.State = ConnectionState.Open Then
            Agente.conexion.Close()
        End If
    End Sub
End Class
