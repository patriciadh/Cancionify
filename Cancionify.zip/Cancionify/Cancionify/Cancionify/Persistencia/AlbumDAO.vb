﻿Public Class AlbumDAO
    Public ReadOnly Property Albumes As Collection

    Public Sub New()
        Me.Albumes = New Collection
    End Sub

    Public Sub LeerTodos()
        Dim a As Album
        Dim col, aux As Collection
        col = Agente.ObtenerAgente().Leer("SELECT * FROM Albumes ORDER BY IdAlbum")
        For Each aux In col
            a = New Album(aux(1).ToString)
            a.NombreAlbum = aux(2).ToString
            a.FechaAlbum = aux(3).ToString
            a.ArtistaAlbum = aux(4).ToString
            a.Portada = aux(5).ToString
            Me.Albumes.Add(a)
        Next
    End Sub

    Public Sub Leer(ByRef a As Album)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT * FROM Albumes WHERE IdAlbum='" & a.IDAlbum & "';")
        For Each aux In col
            a.NombreAlbum = aux(2).ToString
            a.FechaAlbum = aux(3).ToString
            a.ArtistaAlbum = aux(4).ToString
            a.Portada = aux(5).ToString
        Next
    End Sub

    Public Sub LeerAlbumes(ByRef artista As Artista)
        Dim a As Album
        Dim col, aux As Collection
        col = Agente.ObtenerAgente().Leer("SELECT * FROM Albumes WHERE Artista=" & artista.IDArtista & ";")
        For Each aux In col
            a = New Album(aux(1).ToString)
            a.NombreAlbum = aux(2).ToString
            a.FechaAlbum = aux(3).ToString
            a.ArtistaAlbum = aux(4).ToString
            a.Portada = aux(5).ToString
            Me.Albumes.Add(a)
        Next
    End Sub
    Public Sub LeerDuracion(ByRef a As Album)
        Dim col, aux As Collection
        col = Agente.ObtenerAgente().Leer("SELECT SUM(Duracion) FROM Canciones WHERE Album=" & a.IDAlbum & ";")
        For Each aux In col
            If aux(1).ToString = "" Then
                a.DuracionAlbum = 0
            Else
                a.DuracionAlbum = aux(1).ToString
            End If
        Next

    End Sub
    Public Sub LeerAlbum2(ByRef a As Album)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT * FROM Albumes WHERE Nombre='" & a.NombreAlbum & "';")
        For Each aux In col
            a.IDAlbum = aux(1).ToString
            a.FechaAlbum = aux(3).ToString
            a.ArtistaAlbum = aux(4).ToString
            a.Portada = aux(5).ToString
        Next
    End Sub

    Public Function Insertar(ByVal a As Album) As Integer
        a.DuracionAlbum = 0
        Return Agente.ObtenerAgente.Modificar("INSERT INTO Albumes (Nombre, Fecha, Artista, Portada) VALUES ('" & a.NombreAlbum & "', '" & a.FechaAlbum & "', '" & a.ArtistaAlbum & "', '" & a.Portada & "');")
    End Function

    Public Function Actualizar(ByVal a As Album) As Integer
        Return Agente.ObtenerAgente.Modificar("UPDATE Albumes SET Nombre='" & a.NombreAlbum & "', Fecha='" & a.FechaAlbum & "', Artista='" & a.ArtistaAlbum & "' WHERE IdAlbum=" & a.IDAlbum & ";")
    End Function

    Public Function Borrar(ByVal a As Album) As Integer
        Return Agente.ObtenerAgente.Modificar("DELETE FROM Albumes WHERE IdAlbum=" & a.IDAlbum & ";")
    End Function
End Class
