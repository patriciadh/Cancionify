﻿Public Class ArtistaDAO
    Public ReadOnly Property Artistas As Collection

    Public Sub New()
        Me.Artistas = New Collection
    End Sub

    Public Sub LeerTodos()
        Dim a As Artista
        Dim col, aux As Collection
        col = Agente.ObtenerAgente().Leer("SELECT * FROM Artistas ORDER BY IdArtista")
        For Each aux In col
            a = New Artista(aux(1).ToString)
            a.NombreArtista = aux(2).ToString
            a.PaisArtista = aux(3).ToString
            a.Imagen = aux(4).ToString
            Me.Artistas.Add(a)
        Next
    End Sub

    Public Sub Leer(ByRef a As Artista)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT * FROM Artistas WHERE IdArtista=" & a.IDArtista & ";")
        For Each aux In col
            a.NombreArtista = aux(2).ToString
            a.PaisArtista = aux(3).ToString
            a.Imagen = aux(4).ToString
        Next
    End Sub

    Public Sub LeerArtista(ByRef a As Artista)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT * FROM Artistas WHERE Nombre='" & a.NombreArtista & "';")
        For Each aux In col
            a.IDArtista = aux(1).ToString
            a.PaisArtista = aux(3).ToString
            a.Imagen = aux(4).ToString
        Next
    End Sub

    Public Function LeerFav(ByRef u As Usuario, ByRef a As Artista) As Boolean
        Dim col As Collection : Dim aux As Collection
        Dim valor As Integer
        col = Agente.ObtenerAgente.Leer("SELECT COUNT (*) As total FROM Artistas_Favoritos WHERE Usuario='" & u.Email & "' AND Artista=" & a.IDArtista & ";")
        For Each aux In col
            valor = Convert.ToInt32(aux(1).ToString)
        Next
        Return valor > 0
    End Function

    Public Function Insertar(ByVal a As Artista) As Integer
        Return Agente.ObtenerAgente.Modificar("INSERT INTO Artistas (Nombre, Pais, Imagen) VALUES ('" & a.NombreArtista & "', '" & a.PaisArtista & "', '" & a.Imagen & "');")
    End Function

    Public Function Actualizar(ByVal a As Artista) As Integer
        Return Agente.ObtenerAgente.Modificar("UPDATE Artistas SET Nombre='" & a.NombreArtista & "', Pais='" & a.PaisArtista & "' WHERE IdArtista=" & a.IDArtista & ";")
    End Function

    Public Function Borrar(ByVal a As Artista) As Integer
        Return Agente.ObtenerAgente.Modificar("DELETE FROM Artistas WHERE IdArtista=" & a.IDArtista & ";")
    End Function

    ' ARTISTA FAVORITO
    Public Function InsertarFav(ByRef u As Usuario, ByRef a As Artista) As Integer
        Return Agente.ObtenerAgente.Modificar("INSERT INTO Artistas_Favoritos (Usuario, Artista, Fecha) VALUES ('" & u.Email & "', " & a.IDArtista & ", #" & Date.Today & "#);")
    End Function

    Public Function BorrarFav(ByRef u As Usuario, ByRef a As Artista) As Integer
        Return Agente.ObtenerAgente.Modificar("DELETE FROM Artistas_Favoritos WHERE Artista=" & a.IDArtista & " AND Usuario='" & u.Email & "';")
    End Function

    ' CONSULTA 1
    Public Sub Consulta1(pais As String)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre, Count(REPRODUCCIONES.Cancion) AS CuentaDeCancion
                From USUARIOS INNER Join ((ARTISTAS INNER Join (ALBUMES INNER Join CANCIONES On ALBUMES.IdAlbum = CANCIONES.Album) ON ARTISTAS.IdArtista = ALBUMES.Artista) INNER Join REPRODUCCIONES On CANCIONES.IdCancion = REPRODUCCIONES.Cancion) ON USUARIOS.Email = REPRODUCCIONES.Usuario
                Where (((Artistas.Pais) = '" & pais & "'))
                Group By Artistas.Nombre
                Order By Count(REPRODUCCIONES.Cancion) DESC;")

        For Each aux In col
            Me.Artistas.Add(aux(1).ToString)
        Next
    End Sub

    Public Sub Consulta1General()
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre, Count(REPRODUCCIONES.Cancion) AS CuentaDeCancion
                From USUARIOS INNER Join ((ARTISTAS INNER Join (ALBUMES INNER Join CANCIONES On ALBUMES.IdAlbum = CANCIONES.Album) ON ARTISTAS.IdArtista = ALBUMES.Artista) INNER Join REPRODUCCIONES On CANCIONES.IdCancion = REPRODUCCIONES.Cancion) ON USUARIOS.Email = REPRODUCCIONES.Usuario
                Group By Artistas.Nombre
                Order By Count(REPRODUCCIONES.Cancion) DESC;")

        For Each aux In col
            Me.Artistas.Add(aux(1).ToString)
        Next
    End Sub

End Class
