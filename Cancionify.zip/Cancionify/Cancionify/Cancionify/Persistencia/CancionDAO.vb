﻿Public Class CancionDAO
    Public ReadOnly Property Canciones As Collection

    Public Sub New()
        Me.Canciones = New Collection
    End Sub

    Public Sub LeerTodas()
        Dim c As Cancion
        Dim col, aux As Collection
        col = Agente.ObtenerAgente().Leer("SELECT * FROM Canciones ORDER BY IdCancion")
        For Each aux In col
            c = New Cancion(aux(1).ToString)
            c.NombreCancion = aux(2).ToString
            c.Album = aux(3).ToString
            c.DuracionCancion = aux(4).ToString
            Me.Canciones.Add(c)
        Next
    End Sub

    'REPRODUCCIONES
    Public Sub LeerTodasReproducciones(u As Usuario)
        Dim r As Reproduccion
        Dim col, aux As Collection
        col = Agente.ObtenerAgente().Leer("SELECT * FROM Reproducciones WHERE Usuario='" & u.Email & "' ORDER BY IdReproduccion")
        For Each aux In col
            r = New Reproduccion()
            r.IDReproduccion = aux(1).ToString
            r.Usuario = aux(2).ToString
            r.Cancion = Convert.ToInt32(aux(3).ToString)
            r.Fecha = aux(4).ToString
            Me.Canciones.Add(r)
        Next
    End Sub

    Public Sub Leer(ByRef c As Cancion)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT * FROM Canciones WHERE IdCancion=" & c.IDCancion & ";")
        For Each aux In col
            c.NombreCancion = aux(2).ToString
            c.Album = aux(3).ToString
            c.DuracionCancion = aux(4).ToString
        Next
    End Sub

    Public Sub LeerCanciones(ByRef album As Album)
        Dim c As Cancion
        Dim col, aux As Collection
        col = Agente.ObtenerAgente().Leer("SELECT * FROM Canciones WHERE Album=" & album.IDAlbum & ";")
        For Each aux In col
            c = New Cancion(aux(1).ToString)
            c.NombreCancion = aux(2).ToString
            c.Album = aux(3).ToString
            c.DuracionCancion = aux(4).ToString
            Me.Canciones.Add(c)
        Next
    End Sub

    Public Sub LeerCancion2(ByRef c As Cancion)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT * FROM Canciones WHERE Nombre='" & c.NombreCancion & "';")
        For Each aux In col
            c.IDCancion = aux(1).ToString
            c.Album = aux(3).ToString
            c.DuracionCancion = aux(4).ToString
        Next
    End Sub

    Public Function Insertar(ByVal c As Cancion) As Integer
        Return Agente.ObtenerAgente.Modificar("INSERT INTO Canciones (Nombre, Album, Duracion) VALUES ('" & c.NombreCancion & "', '" & c.Album & "', '" & c.DuracionCancion & "');")
    End Function

    Public Function Actualizar(ByVal c As Cancion) As Integer
        Return Agente.ObtenerAgente.Modificar("UPDATE Canciones SET Nombre='" & c.NombreCancion & "', Album='" & c.Album & "', Duracion='" & c.DuracionCancion & "' WHERE IdCancion=" & c.IDCancion & ";")
    End Function

    Public Function Borrar(ByVal c As Cancion) As Integer
        Return Agente.ObtenerAgente.Modificar("DELETE FROM Canciones WHERE IdCancion=" & c.IDCancion & ";")
    End Function

    Public Function InsertarReproduccion(ByVal r As Reproduccion) As Integer
        Return Agente.ObtenerAgente.Modificar("INSERT INTO Reproducciones (Usuario, Cancion, Fecha) VALUES ('" & r.Usuario & "', " & r.Cancion & ", #" & Date.Today & "#);")
    End Function

    ' CONSULTA 2
    Public Sub Consulta2()
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT CANCIONES.Nombre, Count(REPRODUCCIONES.Cancion) AS CuentaDeCancion
                From ALBUMES INNER Join (CANCIONES INNER Join (USUARIOS INNER Join REPRODUCCIONES On USUARIOS.Email = REPRODUCCIONES.Usuario) ON CANCIONES.IdCancion = REPRODUCCIONES.Cancion) ON ALBUMES.IdAlbum = CANCIONES.Album
                Group By Canciones.Nombre
                Order By Count(REPRODUCCIONES.Cancion) DESC;")

        For Each aux In col
            Me.Canciones.Add(aux(1).ToString)
        Next
    End Sub
End Class
