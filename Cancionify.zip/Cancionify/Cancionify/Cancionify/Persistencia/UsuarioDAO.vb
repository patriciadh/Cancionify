﻿Public Class UsuarioDAO
    Public ReadOnly Property Usuarios As Collection

    Public Sub New()
        Me.Usuarios = New Collection
    End Sub

    Public Sub LeerTodos(ruta As String)
        Dim u As Usuario
        Dim col, aux As Collection
        col = Agente.ObtenerAgente(ruta).Leer("SELECT * FROM Usuarios ORDER BY Email")
        For Each aux In col
            u = New Usuario(aux(1).ToString)
            u.Nombre = aux(2).ToString
            u.Apellidos = aux(3).ToString
            u.FechaNac = aux(4).ToString

            Me.Usuarios.Add(u)
        Next
    End Sub

    Public Sub Leer(ByRef u As Usuario)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT * FROM Usuarios WHERE Email='" & u.Email & "';")
        For Each aux In col
            u.Nombre = aux(2).ToString
            u.Apellidos = aux(3).ToString
            u.FechaNac = aux(4).ToString
        Next
    End Sub

    Public Function Insertar(ByVal u As Usuario) As Integer
        Return Agente.ObtenerAgente.Modificar("INSERT INTO Usuarios (Email, Nombre, Apellidos, FechaNacimiento) VALUES ('" & u.Email & "', '" & u.Nombre & "', '" & u.Apellidos & "', '" & u.FechaNac & "');")
    End Function

    Public Function Actualizar(ByVal u As Usuario) As Integer
        Return Agente.ObtenerAgente.Modificar("UPDATE Usuarios SET Nombre='" & u.Nombre & "', Apellidos='" & u.Apellidos & "', FechaNacimiento='" & u.FechaNac & "', Email='" & u.Email & "' WHERE Email='" & u.Email & "';")
    End Function

    Public Function Borrar(ByVal u As Usuario) As Integer
        Return Agente.ObtenerAgente.Modificar("DELETE FROM Usuarios WHERE Email='" & u.Email & "';")
    End Function

    ' CONSULTA 3
    Public Sub Consulta3(fechaInicio As Date, fechaFin As Date, u As Usuario)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre
                FROM ARTISTAS INNER Join (ALBUMES INNER Join (CANCIONES INNER Join (USUARIOS INNER Join REPRODUCCIONES On Usuarios.Email = REPRODUCCIONES.Usuario) ON CANCIONES.IdCancion = REPRODUCCIONES.Cancion) ON ALBUMES.IdAlbum = CANCIONES.Album) ON ARTISTAS.IdArtista = ALBUMES.Artista
                Where (((Usuarios.Nombre) = '" & u.Nombre & "') And ((REPRODUCCIONES.Fecha) > #" & fechaInicio & "# And (REPRODUCCIONES.Fecha) < #" & fechaFin & "#))
                Group By ARTISTAS.Nombre;")

        For Each aux In col
            Me.Usuarios.Add(aux(1).ToString)
        Next
    End Sub

    ' CONSULTA 4
    Public Sub Consulta4()
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT USUARIOS.Email, Sum(CANCIONES.Duracion) As SumaDeDuracion, Count(REPRODUCCIONES.Cancion) AS CuentaDeCancion
                From USUARIOS INNER Join ((ARTISTAS INNER Join (ALBUMES INNER Join CANCIONES On ALBUMES.IdAlbum = CANCIONES.Album) ON ARTISTAS.IdArtista = ALBUMES.Artista) INNER Join REPRODUCCIONES On CANCIONES.IdCancion = REPRODUCCIONES.Cancion) ON USUARIOS.Email = REPRODUCCIONES.Usuario
                Group By USUARIOS.Email
                Order By Sum(CANCIONES.Duracion) DESC;")

        For Each aux In col
            Me.Usuarios.Add(aux(1).ToString)
        Next
    End Sub

    ' CONSULTA 5
    Public Sub Consulta5(u As Usuario)
        Dim col As Collection : Dim aux As Collection
        col = Agente.ObtenerAgente.Leer("SELECT Sum(CANCIONES.Duracion) As SumaDeDuracion
                FROM(ARTISTAS INNER JOIN (ALBUMES INNER JOIN (CANCIONES INNER JOIN (USUARIOS INNER JOIN REPRODUCCIONES On USUARIOS.Email = REPRODUCCIONES.Usuario) On CANCIONES.IdCancion = REPRODUCCIONES.Cancion) On ALBUMES.IdAlbum = CANCIONES.Album) On ARTISTAS.IdArtista = ALBUMES.Artista) INNER JOIN ARTISTAS_FAVORITOS On (USUARIOS.Email = ARTISTAS_FAVORITOS.Usuario) And (ARTISTAS.IdArtista = ARTISTAS_FAVORITOS.Artista)
                WHERE(((Usuarios.Email) = '" & u.Email & "'));")

        For Each aux In col
            Me.Usuarios.Add(aux(1).ToString)
        Next

    End Sub

End Class
