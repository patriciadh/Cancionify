﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAlbum
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnEliminarAlbum = New System.Windows.Forms.Button()
        Me.btnAñadirAlbum = New System.Windows.Forms.Button()
        Me.btnModificarAlbum = New System.Windows.Forms.Button()
        Me.listaAlbumes = New System.Windows.Forms.ListBox()
        Me.btnSiguienteAlbum = New System.Windows.Forms.Button()
        Me.lblCambiarUsuario = New System.Windows.Forms.Label()
        Me.btnCambiarUsuarioAlbum = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblSiguiente1 = New System.Windows.Forms.Label()
        Me.lblSiguiente2 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtNombreAlbum = New System.Windows.Forms.TextBox()
        Me.txtFechaAlbum = New System.Windows.Forms.TextBox()
        Me.txtArtistaAlbum = New System.Windows.Forms.TextBox()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.grpAlbumes = New System.Windows.Forms.GroupBox()
        Me.lblDur = New System.Windows.Forms.Label()
        Me.lblIDAlbum = New System.Windows.Forms.Label()
        Me.path = New System.Windows.Forms.Label()
        Me.btnAtras = New System.Windows.Forms.Button()
        Me.lblDuracionAlbum = New System.Windows.Forms.Label()
        Me.PictureBoxPortada = New System.Windows.Forms.PictureBox()
        Me.grpAlbumes.SuspendLayout()
        CType(Me.PictureBoxPortada, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnEliminarAlbum
        '
        Me.btnEliminarAlbum.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnEliminarAlbum.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEliminarAlbum.Location = New System.Drawing.Point(326, 185)
        Me.btnEliminarAlbum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnEliminarAlbum.Name = "btnEliminarAlbum"
        Me.btnEliminarAlbum.Size = New System.Drawing.Size(92, 33)
        Me.btnEliminarAlbum.TabIndex = 11
        Me.btnEliminarAlbum.Text = "ELIMINAR ÁLBUM"
        Me.btnEliminarAlbum.UseVisualStyleBackColor = False
        '
        'btnAñadirAlbum
        '
        Me.btnAñadirAlbum.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnAñadirAlbum.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAñadirAlbum.Location = New System.Drawing.Point(326, 285)
        Me.btnAñadirAlbum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnAñadirAlbum.Name = "btnAñadirAlbum"
        Me.btnAñadirAlbum.Size = New System.Drawing.Size(92, 35)
        Me.btnAñadirAlbum.TabIndex = 7
        Me.btnAñadirAlbum.Text = "AÑADIR ÁLBUM"
        Me.btnAñadirAlbum.UseVisualStyleBackColor = False
        '
        'btnModificarAlbum
        '
        Me.btnModificarAlbum.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnModificarAlbum.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnModificarAlbum.Location = New System.Drawing.Point(326, 236)
        Me.btnModificarAlbum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnModificarAlbum.Name = "btnModificarAlbum"
        Me.btnModificarAlbum.Size = New System.Drawing.Size(92, 35)
        Me.btnModificarAlbum.TabIndex = 10
        Me.btnModificarAlbum.Text = "MODIFICAR ÁLBUM"
        Me.btnModificarAlbum.UseVisualStyleBackColor = False
        '
        'listaAlbumes
        '
        Me.listaAlbumes.BackColor = System.Drawing.Color.White
        Me.listaAlbumes.FormattingEnabled = True
        Me.listaAlbumes.ItemHeight = 16
        Me.listaAlbumes.Location = New System.Drawing.Point(8, 58)
        Me.listaAlbumes.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.listaAlbumes.Name = "listaAlbumes"
        Me.listaAlbumes.Size = New System.Drawing.Size(411, 100)
        Me.listaAlbumes.TabIndex = 13
        '
        'btnSiguienteAlbum
        '
        Me.btnSiguienteAlbum.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnSiguienteAlbum.Enabled = False
        Me.btnSiguienteAlbum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSiguienteAlbum.Location = New System.Drawing.Point(723, 415)
        Me.btnSiguienteAlbum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnSiguienteAlbum.Name = "btnSiguienteAlbum"
        Me.btnSiguienteAlbum.Size = New System.Drawing.Size(85, 39)
        Me.btnSiguienteAlbum.TabIndex = 14
        Me.btnSiguienteAlbum.Text = "SIGUIENTE"
        Me.btnSiguienteAlbum.UseVisualStyleBackColor = False
        '
        'lblCambiarUsuario
        '
        Me.lblCambiarUsuario.AutoSize = True
        Me.lblCambiarUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCambiarUsuario.Location = New System.Drawing.Point(507, 19)
        Me.lblCambiarUsuario.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCambiarUsuario.Name = "lblCambiarUsuario"
        Me.lblCambiarUsuario.Size = New System.Drawing.Size(309, 17)
        Me.lblCambiarUsuario.TabIndex = 21
        Me.lblCambiarUsuario.Text = "Para cambiar de usuario seleccione este botón:"
        '
        'btnCambiarUsuarioAlbum
        '
        Me.btnCambiarUsuarioAlbum.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCambiarUsuarioAlbum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCambiarUsuarioAlbum.Location = New System.Drawing.Point(629, 48)
        Me.btnCambiarUsuarioAlbum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnCambiarUsuarioAlbum.Name = "btnCambiarUsuarioAlbum"
        Me.btnCambiarUsuarioAlbum.Size = New System.Drawing.Size(179, 45)
        Me.btnCambiarUsuarioAlbum.TabIndex = 22
        Me.btnCambiarUsuarioAlbum.Text = "CAMBIAR DE USUARIO"
        Me.btnCambiarUsuarioAlbum.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(5, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(279, 17)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Seleccione el álbum al que desea acceder:"
        '
        'lblSiguiente1
        '
        Me.lblSiguiente1.AutoSize = True
        Me.lblSiguiente1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSiguiente1.Location = New System.Drawing.Point(615, 368)
        Me.lblSiguiente1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSiguiente1.Name = "lblSiguiente1"
        Me.lblSiguiente1.Size = New System.Drawing.Size(193, 17)
        Me.lblSiguiente1.TabIndex = 24
        Me.lblSiguiente1.Text = "Si ha seleccionado un álbum,"
        '
        'lblSiguiente2
        '
        Me.lblSiguiente2.AutoSize = True
        Me.lblSiguiente2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSiguiente2.Location = New System.Drawing.Point(507, 385)
        Me.lblSiguiente2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSiguiente2.Name = "lblSiguiente2"
        Me.lblSiguiente2.Size = New System.Drawing.Size(301, 17)
        Me.lblSiguiente2.TabIndex = 25
        Me.lblSiguiente2.Text = "pulsa siguiente para acceder a sus canciones:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(63, 207)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 17)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "ID Álbum:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 238)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(145, 17)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Nombre del Álbum:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 270)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 17)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Fecha del álbum:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(79, 304)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 17)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Artista:"
        '
        'txtNombreAlbum
        '
        Me.txtNombreAlbum.BackColor = System.Drawing.Color.White
        Me.txtNombreAlbum.Location = New System.Drawing.Point(152, 236)
        Me.txtNombreAlbum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtNombreAlbum.Name = "txtNombreAlbum"
        Me.txtNombreAlbum.Size = New System.Drawing.Size(157, 23)
        Me.txtNombreAlbum.TabIndex = 38
        '
        'txtFechaAlbum
        '
        Me.txtFechaAlbum.BackColor = System.Drawing.Color.White
        Me.txtFechaAlbum.Location = New System.Drawing.Point(152, 266)
        Me.txtFechaAlbum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtFechaAlbum.Name = "txtFechaAlbum"
        Me.txtFechaAlbum.Size = New System.Drawing.Size(157, 23)
        Me.txtFechaAlbum.TabIndex = 39
        '
        'txtArtistaAlbum
        '
        Me.txtArtistaAlbum.BackColor = System.Drawing.Color.White
        Me.txtArtistaAlbum.Location = New System.Drawing.Point(152, 301)
        Me.txtArtistaAlbum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtArtistaAlbum.Name = "txtArtistaAlbum"
        Me.txtArtistaAlbum.Size = New System.Drawing.Size(157, 23)
        Me.txtArtistaAlbum.TabIndex = 40
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnLimpiar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimpiar.Location = New System.Drawing.Point(326, 340)
        Me.btnLimpiar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(92, 35)
        Me.btnLimpiar.TabIndex = 41
        Me.btnLimpiar.Text = "LIMPIAR"
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'grpAlbumes
        '
        Me.grpAlbumes.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grpAlbumes.Controls.Add(Me.lblDur)
        Me.grpAlbumes.Controls.Add(Me.lblIDAlbum)
        Me.grpAlbumes.Controls.Add(Me.path)
        Me.grpAlbumes.Controls.Add(Me.PictureBoxPortada)
        Me.grpAlbumes.Controls.Add(Me.btnAtras)
        Me.grpAlbumes.Controls.Add(Me.btnLimpiar)
        Me.grpAlbumes.Controls.Add(Me.txtArtistaAlbum)
        Me.grpAlbumes.Controls.Add(Me.txtFechaAlbum)
        Me.grpAlbumes.Controls.Add(Me.txtNombreAlbum)
        Me.grpAlbumes.Controls.Add(Me.Label5)
        Me.grpAlbumes.Controls.Add(Me.Label4)
        Me.grpAlbumes.Controls.Add(Me.Label3)
        Me.grpAlbumes.Controls.Add(Me.Label2)
        Me.grpAlbumes.Controls.Add(Me.lblDuracionAlbum)
        Me.grpAlbumes.Controls.Add(Me.lblSiguiente2)
        Me.grpAlbumes.Controls.Add(Me.lblSiguiente1)
        Me.grpAlbumes.Controls.Add(Me.Label1)
        Me.grpAlbumes.Controls.Add(Me.btnCambiarUsuarioAlbum)
        Me.grpAlbumes.Controls.Add(Me.lblCambiarUsuario)
        Me.grpAlbumes.Controls.Add(Me.btnSiguienteAlbum)
        Me.grpAlbumes.Controls.Add(Me.listaAlbumes)
        Me.grpAlbumes.Controls.Add(Me.btnModificarAlbum)
        Me.grpAlbumes.Controls.Add(Me.btnAñadirAlbum)
        Me.grpAlbumes.Controls.Add(Me.btnEliminarAlbum)
        Me.grpAlbumes.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpAlbumes.Location = New System.Drawing.Point(12, 12)
        Me.grpAlbumes.Name = "grpAlbumes"
        Me.grpAlbumes.Size = New System.Drawing.Size(818, 470)
        Me.grpAlbumes.TabIndex = 1
        Me.grpAlbumes.TabStop = False
        Me.grpAlbumes.Text = "ÁLBUMES"
        '
        'lblDur
        '
        Me.lblDur.AutoSize = True
        Me.lblDur.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDur.Location = New System.Drawing.Point(643, 207)
        Me.lblDur.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDur.Name = "lblDur"
        Me.lblDur.Size = New System.Drawing.Size(165, 17)
        Me.lblDur.TabIndex = 51
        Me.lblDur.Text = "Duración total del álbum:"
        '
        'lblIDAlbum
        '
        Me.lblIDAlbum.AutoSize = True
        Me.lblIDAlbum.Location = New System.Drawing.Point(155, 207)
        Me.lblIDAlbum.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblIDAlbum.Name = "lblIDAlbum"
        Me.lblIDAlbum.Size = New System.Drawing.Size(0, 17)
        Me.lblIDAlbum.TabIndex = 50
        '
        'path
        '
        Me.path.AutoSize = True
        Me.path.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.path.Location = New System.Drawing.Point(426, 115)
        Me.path.Name = "path"
        Me.path.Size = New System.Drawing.Size(87, 17)
        Me.path.TabIndex = 49
        Me.path.Text = "PORTADA:"
        Me.path.Visible = False
        '
        'btnAtras
        '
        Me.btnAtras.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAtras.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAtras.Location = New System.Drawing.Point(13, 416)
        Me.btnAtras.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnAtras.Name = "btnAtras"
        Me.btnAtras.Size = New System.Drawing.Size(85, 38)
        Me.btnAtras.TabIndex = 45
        Me.btnAtras.Text = "ATRÁS"
        Me.btnAtras.UseVisualStyleBackColor = False
        '
        'lblDuracionAlbum
        '
        Me.lblDuracionAlbum.AutoSize = True
        Me.lblDuracionAlbum.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDuracionAlbum.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblDuracionAlbum.Location = New System.Drawing.Point(696, 238)
        Me.lblDuracionAlbum.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDuracionAlbum.Name = "lblDuracionAlbum"
        Me.lblDuracionAlbum.Size = New System.Drawing.Size(0, 17)
        Me.lblDuracionAlbum.TabIndex = 29
        '
        'PictureBoxPortada
        '
        Me.PictureBoxPortada.Image = Global.Cancionify.My.Resources.Resources.error_404_no_encontrado_efecto_falla_8024_4
        Me.PictureBoxPortada.Location = New System.Drawing.Point(429, 142)
        Me.PictureBoxPortada.Name = "PictureBoxPortada"
        Me.PictureBoxPortada.Size = New System.Drawing.Size(205, 216)
        Me.PictureBoxPortada.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxPortada.TabIndex = 48
        Me.PictureBoxPortada.TabStop = False
        '
        'frmAlbum
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(842, 492)
        Me.Controls.Add(Me.grpAlbumes)
        Me.Name = "frmAlbum"
        Me.Text = "ÁLBUMES"
        Me.grpAlbumes.ResumeLayout(False)
        Me.grpAlbumes.PerformLayout()
        CType(Me.PictureBoxPortada, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnEliminarAlbum As Button
    Friend WithEvents btnAñadirAlbum As Button
    Friend WithEvents btnModificarAlbum As Button
    Friend WithEvents listaAlbumes As ListBox
    Friend WithEvents btnSiguienteAlbum As Button
    Friend WithEvents lblCambiarUsuario As Label
    Friend WithEvents btnCambiarUsuarioAlbum As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblSiguiente1 As Label
    Friend WithEvents lblSiguiente2 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtNombreAlbum As TextBox
    Friend WithEvents txtFechaAlbum As TextBox
    Friend WithEvents txtArtistaAlbum As TextBox
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents grpAlbumes As GroupBox
    Friend WithEvents btnAtras As Button
    Friend WithEvents lblDuracionAlbum As Label
    Friend WithEvents PictureBoxPortada As PictureBox
    Friend WithEvents path As Label
    Friend WithEvents lblIDAlbum As Label
    Friend WithEvents lblDur As Label
End Class
