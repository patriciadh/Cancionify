﻿Imports System.Globalization

Public Class frmAlbum
    Public Sub listaAlbumes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaAlbumes.SelectedIndexChanged
        Dim Albaux As Album
        If listaAlbumes.SelectedItem IsNot Nothing Then
            Try
                Albaux = New Album(listaAlbumes.SelectedItem.ToString)
                Albaux.LeerNombreAlbum2()
                Me.path.Visible = False
                lblIDAlbum.Text = Albaux.IDAlbum
                txtNombreAlbum.Text = Albaux.NombreAlbum
                txtFechaAlbum.Text = Albaux.FechaAlbum
                txtArtistaAlbum.Text = Albaux.ArtistaAlbum
                Albaux.LeerDuracionAlbum()
                lblDuracionAlbum.Text = Albaux.DuracionAlbum

                ' PASO DE SEGUNDOS A MINUTOS
                Dim mHours As Long, mMinutes As Long, mSeconds As Long
                mSeconds = Convert.ToInt32(lblDuracionAlbum.Text)
                mHours = mSeconds \ 3600
                mMinutes = (mSeconds - (mHours * 3600)) \ 60
                mSeconds = mSeconds - ((mHours * 3600) + (mMinutes * 60))
                lblDuracionAlbum.Text = (mHours & ":" & mMinutes & ":" & mSeconds)

                Me.PictureBoxPortada.Visible = True
                Me.path.Text = Albaux.Portada

                btnModificarAlbum.Enabled = True
                btnEliminarAlbum.Enabled = True
                btnAñadirAlbum.Enabled = False
                btnSiguienteAlbum.Enabled = True

                PictureBoxPortada.Image = Image.FromFile(Application.StartupPath + "\PortadasAlbum\" + Albaux.NombreAlbum + ".jpg")

            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
        End If
    End Sub

    Public Sub btnAñadirAlbum_Click(sender As Object, e As EventArgs) Handles btnAñadirAlbum.Click
        Dim Aaux As Album
        If txtNombreAlbum.Text IsNot String.Empty And txtFechaAlbum.Text IsNot String.Empty And txtArtistaAlbum.Text IsNot String.Empty Then
            Try
                Aaux = New Album(lblIDAlbum.Text)
                Aaux.DuracionAlbum = 0
                Aaux.NombreAlbum = txtNombreAlbum.Text
                Aaux.FechaAlbum = txtFechaAlbum.Text
                Aaux.Portada = Application.StartupPath + "\PortadasAlbum\" + Aaux.NombreAlbum + ".jpg"
                Aaux.ArtistaAlbum = txtArtistaAlbum.Text
                If Aaux.InsertarAlbum() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaAlbumes.Items.Add(Aaux.NombreAlbum)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        lblIDAlbum.Text = String.Empty
        txtFechaAlbum.Text = String.Empty
        txtNombreAlbum.Text = String.Empty

        btnModificarAlbum.Enabled = False
        btnEliminarAlbum.Enabled = False
        btnAñadirAlbum.Enabled = True
    End Sub

    Public Sub btnModificarAlbum_Click(sender As Object, e As EventArgs) Handles btnModificarAlbum.Click
        Dim Aaux As Album
        If listaAlbumes.SelectedItem IsNot Nothing Then

            Try
                Aaux = New Album(listaAlbumes.SelectedItem.ToString)
                Aaux.LeerNombreAlbum2()
                Aaux.NombreAlbum = txtNombreAlbum.Text
                Aaux.FechaAlbum = txtFechaAlbum.Text
                Aaux.ArtistaAlbum = txtArtistaAlbum.Text
                If Aaux.ActualizarAlbum() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaAlbumes.Items(listaAlbumes.SelectedIndex) = txtNombreAlbum.Text
                    MessageBox.Show("Nombre para" & Aaux.IDAlbum & " actualizado correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub btnEliminarAlbum_Click(sender As Object, e As EventArgs) Handles btnEliminarAlbum.Click
        Dim Albaux As Album
        If listaAlbumes.SelectedItem IsNot Nothing Then
            Albaux = New Album(listaAlbumes.SelectedItem.ToString)
            Albaux.LeerNombreAlbum2()
            Try
                If Albaux.BorrarAlbum() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaAlbumes.Items.Remove(Albaux.NombreAlbum)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub


    Public Sub btnCambiarUsuarioAlbum_Click(sender As Object, e As EventArgs) Handles btnCambiarUsuarioAlbum.Click
        Me.Hide()
        frmEntrar.Show()
    End Sub

    Public Sub btnSiguienteAlbum_Click(sender As Object, e As EventArgs) Handles btnSiguienteAlbum.Click
        Me.Hide()
        Dim frm As frmCancion
        frm = New frmCancion(listaAlbumes.SelectedItem.ToString)
        frm.Show()
    End Sub

    Public Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Me.Hide()
        frmArtista.Show()
    End Sub

    Public Sub New(a As String)
        InitializeComponent()

        Dim Aaux As Album = New Album
        Dim AauxArtista As New Artista(a)
        AauxArtista.LeerNombreArtista()
        Aaux.LeerNombreAlbum(AauxArtista)
        For Each Al As Album In Aaux.AlbDAO.Albumes
            Me.listaAlbumes.Items.Add(Al.NombreAlbum)
        Next
    End Sub
End Class