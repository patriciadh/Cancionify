﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmArtista
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.grpArtista = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnConsulta1General = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ComboBoxConsulta1 = New System.Windows.Forms.ComboBox()
        Me.listConsulta1 = New System.Windows.Forms.ListBox()
        Me.btnConsulta1 = New System.Windows.Forms.Button()
        Me.listConsulta3 = New System.Windows.Forms.ListBox()
        Me.btnConsulta3 = New System.Windows.Forms.Button()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.path = New System.Windows.Forms.Label()
        Me.PictureBoxImagen = New System.Windows.Forms.PictureBox()
        Me.lblIDArtista = New System.Windows.Forms.Label()
        Me.lblEsFavorito = New System.Windows.Forms.Label()
        Me.btnAtras = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnNoFavorito = New System.Windows.Forms.Button()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.txtPaisArtista = New System.Windows.Forms.TextBox()
        Me.txtNombreArtista = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnFavorito = New System.Windows.Forms.Button()
        Me.lblSiguiente2 = New System.Windows.Forms.Label()
        Me.lblSiguiente1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCambiarUsuario = New System.Windows.Forms.Button()
        Me.lblCambiarUsuario = New System.Windows.Forms.Label()
        Me.btnSiguiente = New System.Windows.Forms.Button()
        Me.listaArtistas = New System.Windows.Forms.ListBox()
        Me.btnModificarArtista = New System.Windows.Forms.Button()
        Me.btnAñadirArtista = New System.Windows.Forms.Button()
        Me.btnEliminarArtista = New System.Windows.Forms.Button()
        Me.grpArtista.SuspendLayout()
        CType(Me.PictureBoxImagen, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpArtista
        '
        Me.grpArtista.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grpArtista.Controls.Add(Me.Label10)
        Me.grpArtista.Controls.Add(Me.btnConsulta1General)
        Me.grpArtista.Controls.Add(Me.Label9)
        Me.grpArtista.Controls.Add(Me.Label8)
        Me.grpArtista.Controls.Add(Me.ComboBoxConsulta1)
        Me.grpArtista.Controls.Add(Me.listConsulta1)
        Me.grpArtista.Controls.Add(Me.btnConsulta1)
        Me.grpArtista.Controls.Add(Me.listConsulta3)
        Me.grpArtista.Controls.Add(Me.btnConsulta3)
        Me.grpArtista.Controls.Add(Me.dtpInicio)
        Me.grpArtista.Controls.Add(Me.dtpFin)
        Me.grpArtista.Controls.Add(Me.path)
        Me.grpArtista.Controls.Add(Me.PictureBoxImagen)
        Me.grpArtista.Controls.Add(Me.lblIDArtista)
        Me.grpArtista.Controls.Add(Me.lblEsFavorito)
        Me.grpArtista.Controls.Add(Me.btnAtras)
        Me.grpArtista.Controls.Add(Me.Label6)
        Me.grpArtista.Controls.Add(Me.btnNoFavorito)
        Me.grpArtista.Controls.Add(Me.btnLimpiar)
        Me.grpArtista.Controls.Add(Me.txtPaisArtista)
        Me.grpArtista.Controls.Add(Me.txtNombreArtista)
        Me.grpArtista.Controls.Add(Me.Label4)
        Me.grpArtista.Controls.Add(Me.Label3)
        Me.grpArtista.Controls.Add(Me.Label2)
        Me.grpArtista.Controls.Add(Me.btnFavorito)
        Me.grpArtista.Controls.Add(Me.lblSiguiente2)
        Me.grpArtista.Controls.Add(Me.lblSiguiente1)
        Me.grpArtista.Controls.Add(Me.Label1)
        Me.grpArtista.Controls.Add(Me.btnCambiarUsuario)
        Me.grpArtista.Controls.Add(Me.lblCambiarUsuario)
        Me.grpArtista.Controls.Add(Me.btnSiguiente)
        Me.grpArtista.Controls.Add(Me.listaArtistas)
        Me.grpArtista.Controls.Add(Me.btnModificarArtista)
        Me.grpArtista.Controls.Add(Me.btnAñadirArtista)
        Me.grpArtista.Controls.Add(Me.btnEliminarArtista)
        Me.grpArtista.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpArtista.Location = New System.Drawing.Point(12, 12)
        Me.grpArtista.Name = "grpArtista"
        Me.grpArtista.Size = New System.Drawing.Size(1009, 735)
        Me.grpArtista.TabIndex = 0
        Me.grpArtista.TabStop = False
        Me.grpArtista.Text = "ARTISTA"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(16, 601)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(560, 17)
        Me.Label10.TabIndex = 73
        Me.Label10.Text = "CONSULTA 1 GENERAL: Listado de artistas ordenados por número de reproducciones" & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'btnConsulta1General
        '
        Me.btnConsulta1General.BackColor = System.Drawing.Color.SandyBrown
        Me.btnConsulta1General.Enabled = False
        Me.btnConsulta1General.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConsulta1General.Location = New System.Drawing.Point(19, 637)
        Me.btnConsulta1General.Margin = New System.Windows.Forms.Padding(2)
        Me.btnConsulta1General.Name = "btnConsulta1General"
        Me.btnConsulta1General.Size = New System.Drawing.Size(175, 26)
        Me.btnConsulta1General.TabIndex = 72
        Me.btnConsulta1General.Text = "CONSULTA 1 GENERAL"
        Me.btnConsulta1General.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(512, 405)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(488, 34)
        Me.Label9.TabIndex = 71
        Me.Label9.Text = "CONSULTA 3:  ""Listado de artistas más escuchados por un usuario (entre 2" & Global.Microsoft.VisualBasic.ChrW(10) & "fechas)." &
    """"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(15, 405)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(495, 34)
        Me.Label8.TabIndex = 70
        Me.Label8.Text = "CONSULTA 1: ""Listado de artistas ordenados por número de reproducciones" & Global.Microsoft.VisualBasic.ChrW(10) & " y permit" &
    "iendo filtrar por país."""
        '
        'ComboBoxConsulta1
        '
        Me.ComboBoxConsulta1.FormattingEnabled = True
        Me.ComboBoxConsulta1.Location = New System.Drawing.Point(18, 481)
        Me.ComboBoxConsulta1.Margin = New System.Windows.Forms.Padding(2)
        Me.ComboBoxConsulta1.Name = "ComboBoxConsulta1"
        Me.ComboBoxConsulta1.Size = New System.Drawing.Size(144, 24)
        Me.ComboBoxConsulta1.TabIndex = 69
        '
        'listConsulta1
        '
        Me.listConsulta1.FormattingEnabled = True
        Me.listConsulta1.ItemHeight = 16
        Me.listConsulta1.Location = New System.Drawing.Point(212, 453)
        Me.listConsulta1.Margin = New System.Windows.Forms.Padding(2)
        Me.listConsulta1.Name = "listConsulta1"
        Me.listConsulta1.Size = New System.Drawing.Size(242, 132)
        Me.listConsulta1.TabIndex = 68
        '
        'btnConsulta1
        '
        Me.btnConsulta1.BackColor = System.Drawing.Color.SandyBrown
        Me.btnConsulta1.Enabled = False
        Me.btnConsulta1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConsulta1.Location = New System.Drawing.Point(19, 524)
        Me.btnConsulta1.Margin = New System.Windows.Forms.Padding(2)
        Me.btnConsulta1.Name = "btnConsulta1"
        Me.btnConsulta1.Size = New System.Drawing.Size(143, 25)
        Me.btnConsulta1.TabIndex = 67
        Me.btnConsulta1.Text = "CONSULTA 1"
        Me.btnConsulta1.UseVisualStyleBackColor = False
        '
        'listConsulta3
        '
        Me.listConsulta3.FormattingEnabled = True
        Me.listConsulta3.ItemHeight = 16
        Me.listConsulta3.Location = New System.Drawing.Point(515, 453)
        Me.listConsulta3.Margin = New System.Windows.Forms.Padding(2)
        Me.listConsulta3.Name = "listConsulta3"
        Me.listConsulta3.Size = New System.Drawing.Size(270, 68)
        Me.listConsulta3.TabIndex = 66
        '
        'btnConsulta3
        '
        Me.btnConsulta3.BackColor = System.Drawing.Color.SandyBrown
        Me.btnConsulta3.Enabled = False
        Me.btnConsulta3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConsulta3.Location = New System.Drawing.Point(822, 514)
        Me.btnConsulta3.Margin = New System.Windows.Forms.Padding(2)
        Me.btnConsulta3.Name = "btnConsulta3"
        Me.btnConsulta3.Size = New System.Drawing.Size(143, 25)
        Me.btnConsulta3.TabIndex = 65
        Me.btnConsulta3.Text = "CONSULTA 3"
        Me.btnConsulta3.UseVisualStyleBackColor = False
        '
        'dtpInicio
        '
        Me.dtpInicio.Location = New System.Drawing.Point(515, 539)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(273, 23)
        Me.dtpInicio.TabIndex = 64
        '
        'dtpFin
        '
        Me.dtpFin.Location = New System.Drawing.Point(515, 572)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(273, 23)
        Me.dtpFin.TabIndex = 63
        '
        'path
        '
        Me.path.AutoSize = True
        Me.path.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.74545!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.path.Location = New System.Drawing.Point(617, 95)
        Me.path.Name = "path"
        Me.path.Size = New System.Drawing.Size(78, 24)
        Me.path.TabIndex = 50
        Me.path.Text = "Imagen:"
        Me.path.Visible = False
        '
        'PictureBoxImagen
        '
        Me.PictureBoxImagen.Image = Global.Cancionify.My.Resources.Resources.error_404_no_encontrado_efecto_falla_8024_4
        Me.PictureBoxImagen.Location = New System.Drawing.Point(621, 122)
        Me.PictureBoxImagen.Name = "PictureBoxImagen"
        Me.PictureBoxImagen.Size = New System.Drawing.Size(273, 263)
        Me.PictureBoxImagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxImagen.TabIndex = 49
        Me.PictureBoxImagen.TabStop = False
        '
        'lblIDArtista
        '
        Me.lblIDArtista.AutoSize = True
        Me.lblIDArtista.Location = New System.Drawing.Point(165, 202)
        Me.lblIDArtista.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblIDArtista.Name = "lblIDArtista"
        Me.lblIDArtista.Size = New System.Drawing.Size(0, 17)
        Me.lblIDArtista.TabIndex = 47
        '
        'lblEsFavorito
        '
        Me.lblEsFavorito.AutoSize = True
        Me.lblEsFavorito.Location = New System.Drawing.Point(542, 187)
        Me.lblEsFavorito.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEsFavorito.Name = "lblEsFavorito"
        Me.lblEsFavorito.Size = New System.Drawing.Size(0, 17)
        Me.lblEsFavorito.TabIndex = 45
        '
        'btnAtras
        '
        Me.btnAtras.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAtras.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAtras.Location = New System.Drawing.Point(19, 687)
        Me.btnAtras.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAtras.Name = "btnAtras"
        Me.btnAtras.Size = New System.Drawing.Size(85, 39)
        Me.btnAtras.TabIndex = 44
        Me.btnAtras.Text = "ATRÁS"
        Me.btnAtras.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(361, 187)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(170, 17)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "El Artista es Favorito: "
        '
        'btnNoFavorito
        '
        Me.btnNoFavorito.BackColor = System.Drawing.Color.PaleGreen
        Me.btnNoFavorito.Enabled = False
        Me.btnNoFavorito.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNoFavorito.Location = New System.Drawing.Point(366, 262)
        Me.btnNoFavorito.Margin = New System.Windows.Forms.Padding(2)
        Me.btnNoFavorito.Name = "btnNoFavorito"
        Me.btnNoFavorito.Size = New System.Drawing.Size(163, 37)
        Me.btnNoFavorito.TabIndex = 42
        Me.btnNoFavorito.Text = "DESMARCAR COMO FAVORITO"
        Me.btnNoFavorito.UseVisualStyleBackColor = False
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnLimpiar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimpiar.Location = New System.Drawing.Point(53, 321)
        Me.btnLimpiar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(92, 35)
        Me.btnLimpiar.TabIndex = 41
        Me.btnLimpiar.Text = "LIMPIAR"
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'txtPaisArtista
        '
        Me.txtPaisArtista.Location = New System.Drawing.Point(169, 269)
        Me.txtPaisArtista.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPaisArtista.Name = "txtPaisArtista"
        Me.txtPaisArtista.Size = New System.Drawing.Size(157, 23)
        Me.txtPaisArtista.TabIndex = 39
        '
        'txtNombreArtista
        '
        Me.txtNombreArtista.Location = New System.Drawing.Point(169, 232)
        Me.txtNombreArtista.Margin = New System.Windows.Forms.Padding(2)
        Me.txtNombreArtista.Name = "txtNombreArtista"
        Me.txtNombreArtista.Size = New System.Drawing.Size(157, 23)
        Me.txtNombreArtista.TabIndex = 38
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(27, 271)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(123, 17)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "País del Artista:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 236)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 17)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Nombre del Artista:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(63, 202)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 17)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "ID Artista:"
        '
        'btnFavorito
        '
        Me.btnFavorito.BackColor = System.Drawing.Color.PaleGreen
        Me.btnFavorito.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFavorito.Location = New System.Drawing.Point(364, 213)
        Me.btnFavorito.Margin = New System.Windows.Forms.Padding(2)
        Me.btnFavorito.Name = "btnFavorito"
        Me.btnFavorito.Size = New System.Drawing.Size(163, 37)
        Me.btnFavorito.TabIndex = 28
        Me.btnFavorito.Text = "MARCAR COMO FAVORITO"
        Me.btnFavorito.UseVisualStyleBackColor = False
        '
        'lblSiguiente2
        '
        Me.lblSiguiente2.AutoSize = True
        Me.lblSiguiente2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSiguiente2.Location = New System.Drawing.Point(705, 668)
        Me.lblSiguiente2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSiguiente2.Name = "lblSiguiente2"
        Me.lblSiguiente2.Size = New System.Drawing.Size(290, 17)
        Me.lblSiguiente2.TabIndex = 25
        Me.lblSiguiente2.Text = "pulsa siguiente para acceder a sus álbumes:"
        '
        'lblSiguiente1
        '
        Me.lblSiguiente1.AutoSize = True
        Me.lblSiguiente1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSiguiente1.Location = New System.Drawing.Point(790, 652)
        Me.lblSiguiente1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSiguiente1.Name = "lblSiguiente1"
        Me.lblSiguiente1.Size = New System.Drawing.Size(194, 17)
        Me.lblSiguiente1.TabIndex = 24
        Me.lblSiguiente1.Text = "Si ha seleccionado un artista,"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(5, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(280, 17)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Seleccione el artista al que desea acceder:"
        '
        'btnCambiarUsuario
        '
        Me.btnCambiarUsuario.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCambiarUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCambiarUsuario.Location = New System.Drawing.Point(805, 58)
        Me.btnCambiarUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCambiarUsuario.Name = "btnCambiarUsuario"
        Me.btnCambiarUsuario.Size = New System.Drawing.Size(179, 45)
        Me.btnCambiarUsuario.TabIndex = 22
        Me.btnCambiarUsuario.Text = "CAMBIAR DE USUARIO"
        Me.btnCambiarUsuario.UseVisualStyleBackColor = False
        '
        'lblCambiarUsuario
        '
        Me.lblCambiarUsuario.AutoSize = True
        Me.lblCambiarUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCambiarUsuario.Location = New System.Drawing.Point(684, 28)
        Me.lblCambiarUsuario.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCambiarUsuario.Name = "lblCambiarUsuario"
        Me.lblCambiarUsuario.Size = New System.Drawing.Size(309, 17)
        Me.lblCambiarUsuario.TabIndex = 21
        Me.lblCambiarUsuario.Text = "Para cambiar de usuario seleccione este botón:"
        '
        'btnSiguiente
        '
        Me.btnSiguiente.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnSiguiente.Enabled = False
        Me.btnSiguiente.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSiguiente.Location = New System.Drawing.Point(910, 687)
        Me.btnSiguiente.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSiguiente.Name = "btnSiguiente"
        Me.btnSiguiente.Size = New System.Drawing.Size(85, 39)
        Me.btnSiguiente.TabIndex = 14
        Me.btnSiguiente.Text = "SIGUIENTE"
        Me.btnSiguiente.UseVisualStyleBackColor = False
        '
        'listaArtistas
        '
        Me.listaArtistas.FormattingEnabled = True
        Me.listaArtistas.ItemHeight = 16
        Me.listaArtistas.Location = New System.Drawing.Point(19, 58)
        Me.listaArtistas.Margin = New System.Windows.Forms.Padding(2)
        Me.listaArtistas.Name = "listaArtistas"
        Me.listaArtistas.Size = New System.Drawing.Size(510, 116)
        Me.listaArtistas.TabIndex = 13
        '
        'btnModificarArtista
        '
        Me.btnModificarArtista.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnModificarArtista.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnModificarArtista.Location = New System.Drawing.Point(275, 321)
        Me.btnModificarArtista.Margin = New System.Windows.Forms.Padding(2)
        Me.btnModificarArtista.Name = "btnModificarArtista"
        Me.btnModificarArtista.Size = New System.Drawing.Size(92, 35)
        Me.btnModificarArtista.TabIndex = 10
        Me.btnModificarArtista.Text = "MODIFICAR ARTISTA"
        Me.btnModificarArtista.UseVisualStyleBackColor = False
        '
        'btnAñadirArtista
        '
        Me.btnAñadirArtista.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnAñadirArtista.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAñadirArtista.Location = New System.Drawing.Point(162, 321)
        Me.btnAñadirArtista.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAñadirArtista.Name = "btnAñadirArtista"
        Me.btnAñadirArtista.Size = New System.Drawing.Size(92, 35)
        Me.btnAñadirArtista.TabIndex = 7
        Me.btnAñadirArtista.Text = "AÑADIR ARTISTA"
        Me.btnAñadirArtista.UseVisualStyleBackColor = False
        '
        'btnEliminarArtista
        '
        Me.btnEliminarArtista.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnEliminarArtista.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEliminarArtista.Location = New System.Drawing.Point(386, 321)
        Me.btnEliminarArtista.Margin = New System.Windows.Forms.Padding(2)
        Me.btnEliminarArtista.Name = "btnEliminarArtista"
        Me.btnEliminarArtista.Size = New System.Drawing.Size(92, 35)
        Me.btnEliminarArtista.TabIndex = 11
        Me.btnEliminarArtista.Text = "ELIMINAR ARTISTA"
        Me.btnEliminarArtista.UseVisualStyleBackColor = False
        '
        'frmArtista
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1029, 749)
        Me.Controls.Add(Me.grpArtista)
        Me.Name = "frmArtista"
        Me.Text = "ARTISTAS"
        Me.grpArtista.ResumeLayout(False)
        Me.grpArtista.PerformLayout()
        CType(Me.PictureBoxImagen, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpArtista As GroupBox
    Friend WithEvents btnAñadirArtista As Button
    Friend WithEvents btnModificarArtista As Button
    Friend WithEvents btnEliminarArtista As Button
    Friend WithEvents listaArtistas As ListBox
    Friend WithEvents btnSiguiente As Button
    Friend WithEvents lblCambiarUsuario As Label
    Friend WithEvents btnCambiarUsuario As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblSiguiente1 As Label
    Friend WithEvents lblSiguiente2 As Label
    Friend WithEvents btnFavorito As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtPaisArtista As TextBox
    Friend WithEvents txtNombreArtista As TextBox
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnNoFavorito As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents btnAtras As Button
    Friend WithEvents lblEsFavorito As Label
    Friend WithEvents lblIDArtista As Label
    Friend WithEvents PictureBoxImagen As PictureBox
    Friend WithEvents path As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents ComboBoxConsulta1 As ComboBox
    Friend WithEvents listConsulta1 As ListBox
    Friend WithEvents btnConsulta1 As Button
    Friend WithEvents listConsulta3 As ListBox
    Friend WithEvents btnConsulta3 As Button
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents btnConsulta1General As Button
    Friend WithEvents Label10 As Label
End Class
