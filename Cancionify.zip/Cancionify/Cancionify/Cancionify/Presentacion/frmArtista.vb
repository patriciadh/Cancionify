﻿Public Class frmArtista

    Public Sub btnModificarArtista_Click(sender As Object, e As EventArgs) Handles btnModificarArtista.Click
        Dim Aaux As Artista
        If listaArtistas.SelectedItem IsNot Nothing Then

            Try
                Aaux = New Artista(listaArtistas.SelectedItem.ToString)
                Aaux.LeerNombreArtista()
                Aaux.NombreArtista = txtNombreArtista.Text
                Aaux.PaisArtista = txtPaisArtista.Text
                If Aaux.ActualizarArtista() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaArtistas.Items(listaArtistas.SelectedIndex) = txtNombreArtista.Text
                    MessageBox.Show("Nombre para" & Aaux.IDArtista & " actualizado correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub btnEliminarArtista_Click(sender As Object, e As EventArgs) Handles btnEliminarArtista.Click
        Dim Aaux As Artista
        If listaArtistas.SelectedItem IsNot Nothing Then
            Aaux = New Artista(listaArtistas.SelectedItem.ToString)
            Aaux.LeerNombreArtista()
            Try
                If Aaux.BorrarArtista() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaArtistas.Items.Remove(Aaux.NombreArtista)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub btnAñadirArtista_Click(sender As Object, e As EventArgs) Handles btnAñadirArtista.Click
        Dim Aaux As Artista
        If txtNombreArtista.Text IsNot String.Empty And txtPaisArtista.Text IsNot String.Empty Then
            Try
                Aaux = New Artista()
                Aaux.NombreArtista = txtNombreArtista.Text
                Aaux.PaisArtista = txtPaisArtista.Text
                Aaux.Imagen = Application.StartupPath + "\ImagenesArtista\" + Aaux.NombreArtista + ".jpg"
                If Aaux.InsertarArtista() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaArtistas.Items.Add(Aaux.NombreArtista)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtNombreArtista.Text = String.Empty
        lblIDArtista.Text = String.Empty
        txtPaisArtista.Text = String.Empty
        btnModificarArtista.Enabled = False
        btnEliminarArtista.Enabled = False
        btnAñadirArtista.Enabled = True
    End Sub

    Public Sub listaArtistas_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaArtistas.SelectedIndexChanged
        Dim Aaux As Artista
        Dim u As String
        Dim usuario As Usuario
        If listaArtistas.SelectedItem IsNot Nothing Then
            Try
                Aaux = New Artista(listaArtistas.SelectedItem.ToString)
                u = frmEntrar.listaEmail.SelectedItem.ToString
                usuario = New Usuario(u)
                Aaux.LeerNombreArtista()
                Me.path.Visible = False
                lblIDArtista.Text = Aaux.IDArtista
                txtNombreArtista.Text = Aaux.NombreArtista
                txtPaisArtista.Text = Aaux.PaisArtista
                If Aaux.LeerFavorito(usuario) Then
                    lblEsFavorito.Text = "SI"
                Else
                    lblEsFavorito.Text = "NO"
                End If

                Me.PictureBoxImagen.Visible = True
                Me.path.Text = Aaux.Imagen
                PictureBoxImagen.Image = Image.FromFile(Application.StartupPath + "\ImagenesArtista\" + Aaux.NombreArtista + ".jpg")

                btnModificarArtista.Enabled = True
                btnEliminarArtista.Enabled = True
                btnAñadirArtista.Enabled = False
                btnSiguiente.Enabled = True
                btnConsulta3.Enabled = True
                btnConsulta1General.Enabled = True

                If lblEsFavorito.Text = "SI" Then
                    btnFavorito.Enabled = False
                    btnNoFavorito.Enabled = True
                Else
                    btnFavorito.Enabled = True
                    btnNoFavorito.Enabled = False
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
        End If
    End Sub

    Public Sub btnCambiarUsuario_Click(sender As Object, e As EventArgs) Handles btnCambiarUsuario.Click
        Me.Hide()
        frmEntrar.Show()
    End Sub

    Public Sub btnFavorito_Click(sender As Object, e As EventArgs) Handles btnFavorito.Click
        Dim u As String
        Dim usuario As Usuario
        Dim Aaux As Artista

        If listaArtistas.SelectedItem IsNot Nothing Then
            Aaux = New Artista(listaArtistas.SelectedItem.ToString)
            Aaux.LeerNombreArtista()
            u = frmEntrar.listaEmail.SelectedItem.ToString
            usuario = New Usuario(u)
            If Aaux.InsertarArtistaFav(usuario) <> 1 Then

                MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            Else
                lblEsFavorito.Text = "SI"
            End If
        End If

        btnNoFavorito.Enabled = True
        btnFavorito.Enabled = False
    End Sub

    Public Sub btnSiguiente_Click(sender As Object, e As EventArgs) Handles btnSiguiente.Click
        Me.Hide()
        Dim frm As frmAlbum
        frm = New frmAlbum(listaArtistas.SelectedItem.ToString)
        frm.Show()
    End Sub

    Public Sub btnNoFavorito_Click(sender As Object, e As EventArgs) Handles btnNoFavorito.Click
        Dim u As String
        Dim usuario As Usuario
        Dim Aaux As Artista

        If listaArtistas.SelectedItem IsNot Nothing Then
            Aaux = New Artista(listaArtistas.SelectedItem.ToString)
            Aaux.LeerNombreArtista()
            u = frmEntrar.listaEmail.SelectedItem.ToString
            usuario = New Usuario(u)
            If Aaux.BorrarArtistaFav(usuario) <> 1 Then

                MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            Else
                lblEsFavorito.Text = "NO"
            End If
        End If
        btnNoFavorito.Enabled = False
        btnFavorito.Enabled = True
    End Sub

    Public Sub frmArtista_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Aaux As Artista = New Artista
        Aaux.LeerTodosArtistas()
        For Each Ar As Artista In Aaux.ArtDAO.Artistas
            listaArtistas.Items.Add(Ar.NombreArtista)
            ComboBoxConsulta1.Items.Add(Ar.PaisArtista)
        Next
    End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Me.Hide()
        frmEntrar.Show()
    End Sub

    ' CONSULTA 1
    Private Sub btnConsulta1_Click_1(sender As Object, e As EventArgs) Handles btnConsulta1.Click

        Dim artista As New Artista(listaArtistas.SelectedItem.ToString)

        artista.LeerArtista()

        artista.Consulta1(ComboBoxConsulta1.SelectedItem.ToString)

        listConsulta1.Items.Clear()

        For Each con1 As String In artista.ArtDAO.Artistas
            listConsulta1.Items.Add(con1)
        Next

    End Sub
    ' CONSULTA 1 GENERAL
    Private Sub btnConsulta1General_Click(sender As Object, e As EventArgs) Handles btnConsulta1General.Click

        Dim artista As New Artista(listaArtistas.SelectedItem.ToString)
        artista.LeerArtista()

        artista.Consulta1General()

        listConsulta1.Items.Clear()

        For Each con1 As String In artista.ArtDAO.Artistas
            listConsulta1.Items.Add(con1)
        Next
    End Sub

    Private Sub ComboBoxConsulta1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxConsulta1.SelectedIndexChanged
        If ComboBoxConsulta1.SelectedItem.ToString IsNot Nothing Then
            btnConsulta1.Enabled = True
        End If
    End Sub

    ' CONSULTA 3
    Private Sub btnConsulta3_Click(sender As Object, e As EventArgs) Handles btnConsulta3.Click
        Dim usuario As New Usuario(frmEntrar.listaEmail.SelectedItem.ToString)
        usuario.LeerUsuario()
        usuario.Consulta3(dtpInicio.Value, dtpFin.Value)

        listConsulta3.Items.Clear()

        For Each sr As String In usuario.UsuDAO.Usuarios
            listConsulta3.Items.Add(sr)
        Next
    End Sub
End Class