﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCancion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.grpCancion = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.listConsulta2 = New System.Windows.Forms.ListBox()
        Me.btnConsulta2 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.listaReproducciones = New System.Windows.Forms.ListBox()
        Me.btnParar = New System.Windows.Forms.Button()
        Me.lblIDCancion = New System.Windows.Forms.Label()
        Me.btnAtras = New System.Windows.Forms.Button()
        Me.txtNombreCancion = New System.Windows.Forms.TextBox()
        Me.btnReproducir = New System.Windows.Forms.Button()
        Me.lblReproducir = New System.Windows.Forms.Label()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.txtDuracionCancion = New System.Windows.Forms.TextBox()
        Me.txtAlbum = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCambiarUsuario = New System.Windows.Forms.Button()
        Me.lblCambiarUsuario = New System.Windows.Forms.Label()
        Me.listaCanciones = New System.Windows.Forms.ListBox()
        Me.btnModificarCancion = New System.Windows.Forms.Button()
        Me.btnAñadirCancion = New System.Windows.Forms.Button()
        Me.btnEliminarCancion = New System.Windows.Forms.Button()
        Me.grpCancion.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpCancion
        '
        Me.grpCancion.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grpCancion.Controls.Add(Me.Label8)
        Me.grpCancion.Controls.Add(Me.listConsulta2)
        Me.grpCancion.Controls.Add(Me.btnConsulta2)
        Me.grpCancion.Controls.Add(Me.Label7)
        Me.grpCancion.Controls.Add(Me.listaReproducciones)
        Me.grpCancion.Controls.Add(Me.btnParar)
        Me.grpCancion.Controls.Add(Me.lblIDCancion)
        Me.grpCancion.Controls.Add(Me.btnAtras)
        Me.grpCancion.Controls.Add(Me.txtNombreCancion)
        Me.grpCancion.Controls.Add(Me.btnReproducir)
        Me.grpCancion.Controls.Add(Me.lblReproducir)
        Me.grpCancion.Controls.Add(Me.btnLimpiar)
        Me.grpCancion.Controls.Add(Me.txtDuracionCancion)
        Me.grpCancion.Controls.Add(Me.txtAlbum)
        Me.grpCancion.Controls.Add(Me.Label5)
        Me.grpCancion.Controls.Add(Me.Label4)
        Me.grpCancion.Controls.Add(Me.Label3)
        Me.grpCancion.Controls.Add(Me.Label2)
        Me.grpCancion.Controls.Add(Me.Label1)
        Me.grpCancion.Controls.Add(Me.btnCambiarUsuario)
        Me.grpCancion.Controls.Add(Me.lblCambiarUsuario)
        Me.grpCancion.Controls.Add(Me.listaCanciones)
        Me.grpCancion.Controls.Add(Me.btnModificarCancion)
        Me.grpCancion.Controls.Add(Me.btnAñadirCancion)
        Me.grpCancion.Controls.Add(Me.btnEliminarCancion)
        Me.grpCancion.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpCancion.Location = New System.Drawing.Point(12, 12)
        Me.grpCancion.Name = "grpCancion"
        Me.grpCancion.Size = New System.Drawing.Size(1039, 471)
        Me.grpCancion.TabIndex = 1
        Me.grpCancion.TabStop = False
        Me.grpCancion.Text = "CANCIÓN"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(512, 294)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(522, 17)
        Me.Label8.TabIndex = 73
        Me.Label8.Text = "CONSULTA 2: ""Listado de canciones ordenadas por número de reproducciones."""
        '
        'listConsulta2
        '
        Me.listConsulta2.FormattingEnabled = True
        Me.listConsulta2.ItemHeight = 16
        Me.listConsulta2.Location = New System.Drawing.Point(515, 327)
        Me.listConsulta2.Margin = New System.Windows.Forms.Padding(2)
        Me.listConsulta2.Name = "listConsulta2"
        Me.listConsulta2.Size = New System.Drawing.Size(268, 116)
        Me.listConsulta2.TabIndex = 72
        '
        'btnConsulta2
        '
        Me.btnConsulta2.BackColor = System.Drawing.Color.SandyBrown
        Me.btnConsulta2.Enabled = False
        Me.btnConsulta2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConsulta2.Location = New System.Drawing.Point(802, 377)
        Me.btnConsulta2.Margin = New System.Windows.Forms.Padding(2)
        Me.btnConsulta2.Name = "btnConsulta2"
        Me.btnConsulta2.Size = New System.Drawing.Size(171, 25)
        Me.btnConsulta2.TabIndex = 71
        Me.btnConsulta2.Text = "CONSULTA 2"
        Me.btnConsulta2.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(512, 61)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(185, 17)
        Me.Label7.TabIndex = 51
        Me.Label7.Text = "Historial de reproducciones:"
        '
        'listaReproducciones
        '
        Me.listaReproducciones.FormattingEnabled = True
        Me.listaReproducciones.ItemHeight = 16
        Me.listaReproducciones.Location = New System.Drawing.Point(515, 94)
        Me.listaReproducciones.Margin = New System.Windows.Forms.Padding(2)
        Me.listaReproducciones.Name = "listaReproducciones"
        Me.listaReproducciones.Size = New System.Drawing.Size(268, 148)
        Me.listaReproducciones.TabIndex = 50
        '
        'btnParar
        '
        Me.btnParar.BackColor = System.Drawing.Color.PaleGreen
        Me.btnParar.Enabled = False
        Me.btnParar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnParar.Location = New System.Drawing.Point(822, 177)
        Me.btnParar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnParar.Name = "btnParar"
        Me.btnParar.Size = New System.Drawing.Size(175, 35)
        Me.btnParar.TabIndex = 49
        Me.btnParar.Text = "DEJAR DE REPRODUCIR"
        Me.btnParar.UseVisualStyleBackColor = False
        '
        'lblIDCancion
        '
        Me.lblIDCancion.AutoSize = True
        Me.lblIDCancion.Location = New System.Drawing.Point(187, 275)
        Me.lblIDCancion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblIDCancion.Name = "lblIDCancion"
        Me.lblIDCancion.Size = New System.Drawing.Size(0, 17)
        Me.lblIDCancion.TabIndex = 48
        '
        'btnAtras
        '
        Me.btnAtras.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAtras.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAtras.Location = New System.Drawing.Point(20, 418)
        Me.btnAtras.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAtras.Name = "btnAtras"
        Me.btnAtras.Size = New System.Drawing.Size(92, 35)
        Me.btnAtras.TabIndex = 45
        Me.btnAtras.Text = "INICIO"
        Me.btnAtras.UseVisualStyleBackColor = False
        '
        'txtNombreCancion
        '
        Me.txtNombreCancion.Location = New System.Drawing.Point(190, 311)
        Me.txtNombreCancion.Margin = New System.Windows.Forms.Padding(2)
        Me.txtNombreCancion.Name = "txtNombreCancion"
        Me.txtNombreCancion.Size = New System.Drawing.Size(157, 23)
        Me.txtNombreCancion.TabIndex = 44
        '
        'btnReproducir
        '
        Me.btnReproducir.BackColor = System.Drawing.Color.PaleGreen
        Me.btnReproducir.Enabled = False
        Me.btnReproducir.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReproducir.Location = New System.Drawing.Point(822, 133)
        Me.btnReproducir.Margin = New System.Windows.Forms.Padding(2)
        Me.btnReproducir.Name = "btnReproducir"
        Me.btnReproducir.Size = New System.Drawing.Size(175, 35)
        Me.btnReproducir.TabIndex = 43
        Me.btnReproducir.Text = "REPRODUCIR CANCIÓN"
        Me.btnReproducir.UseVisualStyleBackColor = False
        '
        'lblReproducir
        '
        Me.lblReproducir.AutoSize = True
        Me.lblReproducir.Location = New System.Drawing.Point(633, 255)
        Me.lblReproducir.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblReproducir.Name = "lblReproducir"
        Me.lblReproducir.Size = New System.Drawing.Size(0, 17)
        Me.lblReproducir.TabIndex = 42
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnLimpiar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimpiar.Location = New System.Drawing.Point(189, 418)
        Me.btnLimpiar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(157, 35)
        Me.btnLimpiar.TabIndex = 41
        Me.btnLimpiar.Text = "LIMPIAR"
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'txtDuracionCancion
        '
        Me.txtDuracionCancion.Location = New System.Drawing.Point(190, 372)
        Me.txtDuracionCancion.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDuracionCancion.Name = "txtDuracionCancion"
        Me.txtDuracionCancion.Size = New System.Drawing.Size(157, 23)
        Me.txtDuracionCancion.TabIndex = 40
        '
        'txtAlbum
        '
        Me.txtAlbum.Location = New System.Drawing.Point(190, 342)
        Me.txtAlbum.Margin = New System.Windows.Forms.Padding(2)
        Me.txtAlbum.Name = "txtAlbum"
        Me.txtAlbum.Size = New System.Drawing.Size(157, 23)
        Me.txtAlbum.TabIndex = 39
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 377)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(180, 17)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Duración de la canción:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(118, 347)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 17)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Álbum:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 316)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(173, 17)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Nombre de la Canción:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(86, 275)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 17)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "ID Canción:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(5, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(302, 17)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Seleccione la canción a la que desea acceder:"
        '
        'btnCambiarUsuario
        '
        Me.btnCambiarUsuario.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCambiarUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCambiarUsuario.Location = New System.Drawing.Point(840, 47)
        Me.btnCambiarUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCambiarUsuario.Name = "btnCambiarUsuario"
        Me.btnCambiarUsuario.Size = New System.Drawing.Size(179, 45)
        Me.btnCambiarUsuario.TabIndex = 22
        Me.btnCambiarUsuario.Text = "CAMBIAR DE USUARIO"
        Me.btnCambiarUsuario.UseVisualStyleBackColor = False
        '
        'lblCambiarUsuario
        '
        Me.lblCambiarUsuario.AutoSize = True
        Me.lblCambiarUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCambiarUsuario.Location = New System.Drawing.Point(710, 19)
        Me.lblCambiarUsuario.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCambiarUsuario.Name = "lblCambiarUsuario"
        Me.lblCambiarUsuario.Size = New System.Drawing.Size(309, 17)
        Me.lblCambiarUsuario.TabIndex = 21
        Me.lblCambiarUsuario.Text = "Para cambiar de usuario seleccione este botón:"
        '
        'listaCanciones
        '
        Me.listaCanciones.FormattingEnabled = True
        Me.listaCanciones.ItemHeight = 16
        Me.listaCanciones.Location = New System.Drawing.Point(8, 58)
        Me.listaCanciones.Margin = New System.Windows.Forms.Padding(2)
        Me.listaCanciones.Name = "listaCanciones"
        Me.listaCanciones.Size = New System.Drawing.Size(458, 196)
        Me.listaCanciones.TabIndex = 13
        '
        'btnModificarCancion
        '
        Me.btnModificarCancion.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnModificarCancion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnModificarCancion.Location = New System.Drawing.Point(374, 337)
        Me.btnModificarCancion.Margin = New System.Windows.Forms.Padding(2)
        Me.btnModificarCancion.Name = "btnModificarCancion"
        Me.btnModificarCancion.Size = New System.Drawing.Size(92, 35)
        Me.btnModificarCancion.TabIndex = 10
        Me.btnModificarCancion.Text = "MODIFICAR CANCIÓN"
        Me.btnModificarCancion.UseVisualStyleBackColor = False
        '
        'btnAñadirCancion
        '
        Me.btnAñadirCancion.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnAñadirCancion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAñadirCancion.Location = New System.Drawing.Point(374, 284)
        Me.btnAñadirCancion.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAñadirCancion.Name = "btnAñadirCancion"
        Me.btnAñadirCancion.Size = New System.Drawing.Size(92, 35)
        Me.btnAñadirCancion.TabIndex = 7
        Me.btnAñadirCancion.Text = "AÑADIR CANCIÓN"
        Me.btnAñadirCancion.UseVisualStyleBackColor = False
        '
        'btnEliminarCancion
        '
        Me.btnEliminarCancion.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnEliminarCancion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEliminarCancion.Location = New System.Drawing.Point(374, 393)
        Me.btnEliminarCancion.Margin = New System.Windows.Forms.Padding(2)
        Me.btnEliminarCancion.Name = "btnEliminarCancion"
        Me.btnEliminarCancion.Size = New System.Drawing.Size(92, 35)
        Me.btnEliminarCancion.TabIndex = 11
        Me.btnEliminarCancion.Text = "ELIMINAR CANCIÓN"
        Me.btnEliminarCancion.UseVisualStyleBackColor = False
        '
        'frmCancion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1063, 495)
        Me.Controls.Add(Me.grpCancion)
        Me.Name = "frmCancion"
        Me.Text = "CANCIONES"
        Me.grpCancion.ResumeLayout(False)
        Me.grpCancion.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpCancion As GroupBox
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents txtDuracionCancion As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCambiarUsuario As Button
    Friend WithEvents lblCambiarUsuario As Label
    Friend WithEvents listaCanciones As ListBox
    Friend WithEvents btnModificarCancion As Button
    Friend WithEvents btnAñadirCancion As Button
    Friend WithEvents btnEliminarCancion As Button
    Friend WithEvents btnReproducir As Button
    Friend WithEvents txtNombreCancion As TextBox
    Friend WithEvents btnAtras As Button
    Friend WithEvents lblIDCancion As Label
    Friend WithEvents lblReproducir As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtAlbum As TextBox
    Friend WithEvents btnParar As Button
    Friend WithEvents listaReproducciones As ListBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents listConsulta2 As ListBox
    Friend WithEvents btnConsulta2 As Button
End Class
