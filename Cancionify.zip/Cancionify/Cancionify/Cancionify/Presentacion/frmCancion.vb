﻿Imports System.Globalization

Public Class frmCancion
    Public Sub listaCanciones_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaCanciones.SelectedIndexChanged
        Dim Canaux As Cancion
        If listaCanciones.SelectedItem IsNot Nothing Then
            Try
                Canaux = New Cancion(listaCanciones.SelectedItem.ToString)
                Canaux.LeerNombreCancion2()
                lblIDCancion.Text = Canaux.IDCancion
                txtNombreCancion.Text = Canaux.NombreCancion
                txtAlbum.Text = Canaux.Album
                txtDuracionCancion.Text = Canaux.DuracionCancion

                ' PASO DE SEGUNDOS A MINUTOS
                Dim mHours As Long, mMinutes As Long, mSeconds As Long
                mSeconds = Convert.ToInt32(txtDuracionCancion.Text)
                mHours = mSeconds \ 3600
                mMinutes = (mSeconds - (mHours * 3600)) \ 60
                mSeconds = mSeconds - ((mHours * 3600) + (mMinutes * 60))
                txtDuracionCancion.Text = (mHours & ":" & mMinutes & ":" & mSeconds)

                btnReproducir.Enabled = True
                btnModificarCancion.Enabled = True
                btnEliminarCancion.Enabled = True
                btnAñadirCancion.Enabled = False
                btnConsulta2.Enabled = True
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
        End If
    End Sub

    Public Sub btnEliminarCancion_Click(sender As Object, e As EventArgs) Handles btnEliminarCancion.Click
        Dim Canaux As Cancion
        If listaCanciones.SelectedItem IsNot Nothing Then
            Canaux = New Cancion(listaCanciones.SelectedItem.ToString)
            Canaux.LeerNombreCancion2()
            Try
                If Canaux.BorrarCancion() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaCanciones.Items.Remove(Canaux.NombreCancion)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub btnModificarCancion_Click(sender As Object, e As EventArgs) Handles btnModificarCancion.Click
        Dim Canaux As Cancion
        If listaCanciones.SelectedItem IsNot Nothing Then

            Try
                Canaux = New Cancion(listaCanciones.SelectedItem.ToString)
                Canaux.LeerNombreCancion2()
                Canaux.NombreCancion = txtNombreCancion.Text
                Canaux.Album = txtAlbum.Text
                Canaux.DuracionCancion = txtDuracionCancion.Text
                If Canaux.ActualizarCancion() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaCanciones.Items(listaCanciones.SelectedIndex) = txtNombreCancion.Text
                    MessageBox.Show("Nombre para" & Canaux.IDCancion & " actualizado correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub btnAñadirCancion_Click(sender As Object, e As EventArgs) Handles btnAñadirCancion.Click
        Dim Canaux As Cancion
        If txtNombreCancion.Text IsNot String.Empty And txtAlbum.Text IsNot String.Empty And txtDuracionCancion.Text IsNot String.Empty Then

            Try
                Canaux = New Cancion(lblIDCancion.Text)
                Canaux.NombreCancion = txtNombreCancion.Text
                Canaux.Album = txtAlbum.Text
                Canaux.DuracionCancion = txtDuracionCancion.Text
                If Canaux.InsertarCancion() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaCanciones.Items.Add(Canaux.NombreCancion)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtNombreCancion.Text = String.Empty
        lblIDCancion.Text = String.Empty
        txtDuracionCancion.Text = String.Empty

        btnModificarCancion.Enabled = False
        btnEliminarCancion.Enabled = False
        btnAñadirCancion.Enabled = True
    End Sub

    Public Sub btnReproducir_Click(sender As Object, e As EventArgs) Handles btnReproducir.Click

        Dim Raux As Reproduccion
        Dim cancion As New Cancion
        Raux = New Reproduccion()
        Raux.Cancion = lblIDCancion.Text
        Raux.Fecha = Date.Today
        Raux.Usuario = frmEntrar.listaEmail.SelectedItem.ToString
        Try
            If cancion.InsertarReproducciones(Raux) <> 1 Then
                MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            Else
                cancion.IDCancion = Raux.Cancion
                cancion.LeerCancion()
                listaReproducciones.Items.Add(cancion.NombreCancion & " " & Raux.Fecha)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        btnParar.Enabled = True
        btnReproducir.Enabled = False
        lblReproducir.ForeColor = Color.Blue
        lblReproducir.Text = "Reproduciendo Cancion..."
    End Sub

    Public Sub btnCambiarUsuario_Click(sender As Object, e As EventArgs) Handles btnCambiarUsuario.Click
        Me.Hide()
        frmEntrar.Show()
    End Sub

    Public Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Me.Hide()
        frmEntrar.Show()
    End Sub

    Private Sub btnParar_Click(sender As Object, e As EventArgs) Handles btnParar.Click
        btnReproducir.Enabled = True
        btnParar.Enabled = False
        lblReproducir.ForeColor = Color.Blue
        lblReproducir.Text = "Usted ha dejado de reproducir la canción"
    End Sub

    Public Sub New(a As String)
        InitializeComponent()

        Dim Canaux As Cancion = New Cancion
        Dim AauxAlbum As New Album(a)
        AauxAlbum.LeerNombreAlbum2()
        Canaux.LeerNombreCancion(AauxAlbum)
        For Each Ca As Cancion In Canaux.CanDAO.Canciones
            Me.listaCanciones.Items.Add(Ca.NombreCancion)
        Next
    End Sub

    Private Sub frmCancion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim usuario As Usuario
        usuario = New Usuario(frmEntrar.listaEmail.SelectedItem.ToString)
        Dim cancion As New Cancion
        cancion.LeerTodasReproducciones(usuario)
        For Each Re As Reproduccion In cancion.CanDAO.Canciones
            cancion.IDCancion = Re.Cancion
            cancion.LeerCancion()
            listaReproducciones.Items.Add(cancion.NombreCancion & " " & Re.Fecha) ' concatenar los demás
        Next
    End Sub

    ' CONSULTA 2
    Private Sub btnConsulta2_Click(sender As Object, e As EventArgs) Handles btnConsulta2.Click

        Dim cancion As New Cancion(listaCanciones.SelectedItem.ToString)
        cancion.LeerCancion()

        cancion.Consulta2()

        listConsulta2.Items.Clear()

        For Each con2 As String In cancion.CanDAO.Canciones
            listConsulta2.Items.Add(con2)
        Next
    End Sub
End Class