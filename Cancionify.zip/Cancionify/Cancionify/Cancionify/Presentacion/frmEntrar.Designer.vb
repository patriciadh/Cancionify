﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmEntrar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.grpEntrar = New System.Windows.Forms.GroupBox()
        Me.lblConsulta5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnConsulta5 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnConsulta4 = New System.Windows.Forms.Button()
        Me.listConsulta4 = New System.Windows.Forms.ListBox()
        Me.btnEntrar = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.listaEmail = New System.Windows.Forms.ListBox()
        Me.btnModificarUsuarios = New System.Windows.Forms.Button()
        Me.btnRuta = New System.Windows.Forms.Button()
        Me.txtRuta = New System.Windows.Forms.TextBox()
        Me.btnConectar = New System.Windows.Forms.Button()
        Me.lblResultado = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.odfRuta = New System.Windows.Forms.OpenFileDialog()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.grpEntrar.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpEntrar
        '
        Me.grpEntrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grpEntrar.Controls.Add(Me.PictureBox1)
        Me.grpEntrar.Controls.Add(Me.lblConsulta5)
        Me.grpEntrar.Controls.Add(Me.Label4)
        Me.grpEntrar.Controls.Add(Me.btnConsulta5)
        Me.grpEntrar.Controls.Add(Me.Label8)
        Me.grpEntrar.Controls.Add(Me.btnConsulta4)
        Me.grpEntrar.Controls.Add(Me.listConsulta4)
        Me.grpEntrar.Controls.Add(Me.btnEntrar)
        Me.grpEntrar.Controls.Add(Me.Label2)
        Me.grpEntrar.Controls.Add(Me.Label1)
        Me.grpEntrar.Controls.Add(Me.listaEmail)
        Me.grpEntrar.Controls.Add(Me.btnModificarUsuarios)
        Me.grpEntrar.Enabled = False
        Me.grpEntrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpEntrar.Location = New System.Drawing.Point(9, 9)
        Me.grpEntrar.Margin = New System.Windows.Forms.Padding(2)
        Me.grpEntrar.Name = "grpEntrar"
        Me.grpEntrar.Padding = New System.Windows.Forms.Padding(2)
        Me.grpEntrar.Size = New System.Drawing.Size(1002, 374)
        Me.grpEntrar.TabIndex = 3
        Me.grpEntrar.TabStop = False
        Me.grpEntrar.Text = "ENTRAR A CANCIONIFY"
        '
        'lblConsulta5
        '
        Me.lblConsulta5.AutoSize = True
        Me.lblConsulta5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConsulta5.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblConsulta5.Location = New System.Drawing.Point(477, 331)
        Me.lblConsulta5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblConsulta5.Name = "lblConsulta5"
        Me.lblConsulta5.Size = New System.Drawing.Size(0, 17)
        Me.lblConsulta5.TabIndex = 79
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(310, 287)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(452, 34)
        Me.Label4.TabIndex = 77
        Me.Label4.Text = "CONSULTA 5: ""Tiempo de reproducción de los artistas favoritos de un" & Global.Microsoft.VisualBasic.ChrW(10) & "usuario."""
        '
        'btnConsulta5
        '
        Me.btnConsulta5.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.btnConsulta5.Enabled = False
        Me.btnConsulta5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConsulta5.Location = New System.Drawing.Point(314, 327)
        Me.btnConsulta5.Margin = New System.Windows.Forms.Padding(2)
        Me.btnConsulta5.Name = "btnConsulta5"
        Me.btnConsulta5.Size = New System.Drawing.Size(143, 25)
        Me.btnConsulta5.TabIndex = 76
        Me.btnConsulta5.Text = "CONSULTA 5"
        Me.btnConsulta5.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(310, 57)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(474, 51)
        Me.Label8.TabIndex = 74
        Me.Label8.Text = "CONSULTA 4: ""Listado de usuarios ordenado por el tiempo que utilizan la" & Global.Microsoft.VisualBasic.ChrW(10) & "aplicació" &
    "n (en base a la duración total de las canciones" & Global.Microsoft.VisualBasic.ChrW(10) & "reproducidas)."""
        '
        'btnConsulta4
        '
        Me.btnConsulta4.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.btnConsulta4.Enabled = False
        Me.btnConsulta4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConsulta4.Location = New System.Drawing.Point(314, 247)
        Me.btnConsulta4.Margin = New System.Windows.Forms.Padding(2)
        Me.btnConsulta4.Name = "btnConsulta4"
        Me.btnConsulta4.Size = New System.Drawing.Size(143, 25)
        Me.btnConsulta4.TabIndex = 68
        Me.btnConsulta4.Text = "CONSULTA 4"
        Me.btnConsulta4.UseVisualStyleBackColor = False
        '
        'listConsulta4
        '
        Me.listConsulta4.FormattingEnabled = True
        Me.listConsulta4.ItemHeight = 16
        Me.listConsulta4.Location = New System.Drawing.Point(314, 118)
        Me.listConsulta4.Margin = New System.Windows.Forms.Padding(2)
        Me.listConsulta4.Name = "listConsulta4"
        Me.listConsulta4.Size = New System.Drawing.Size(224, 116)
        Me.listConsulta4.TabIndex = 9
        '
        'btnEntrar
        '
        Me.btnEntrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnEntrar.Enabled = False
        Me.btnEntrar.Location = New System.Drawing.Point(872, 303)
        Me.btnEntrar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnEntrar.Name = "btnEntrar"
        Me.btnEntrar.Size = New System.Drawing.Size(118, 49)
        Me.btnEntrar.TabIndex = 8
        Me.btnEntrar.Text = "ENTRAR"
        Me.btnEntrar.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(14, 33)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(296, 22)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Por favor, seleccione su e-mail de la lista:"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(698, 18)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(292, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Para ver y modificar los usuarios, pulsa aquí:"
        '
        'listaEmail
        '
        Me.listaEmail.FormattingEnabled = True
        Me.listaEmail.ItemHeight = 16
        Me.listaEmail.Location = New System.Drawing.Point(16, 57)
        Me.listaEmail.Margin = New System.Windows.Forms.Padding(2)
        Me.listaEmail.Name = "listaEmail"
        Me.listaEmail.Size = New System.Drawing.Size(277, 292)
        Me.listaEmail.TabIndex = 0
        '
        'btnModificarUsuarios
        '
        Me.btnModificarUsuarios.BackColor = System.Drawing.Color.Turquoise
        Me.btnModificarUsuarios.Location = New System.Drawing.Point(792, 43)
        Me.btnModificarUsuarios.Margin = New System.Windows.Forms.Padding(2)
        Me.btnModificarUsuarios.Name = "btnModificarUsuarios"
        Me.btnModificarUsuarios.Size = New System.Drawing.Size(198, 46)
        Me.btnModificarUsuarios.TabIndex = 7
        Me.btnModificarUsuarios.Text = "MODIFICAR USUARIOS"
        Me.btnModificarUsuarios.UseVisualStyleBackColor = False
        '
        'btnRuta
        '
        Me.btnRuta.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnRuta.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRuta.Location = New System.Drawing.Point(38, 413)
        Me.btnRuta.Margin = New System.Windows.Forms.Padding(2)
        Me.btnRuta.Name = "btnRuta"
        Me.btnRuta.Size = New System.Drawing.Size(104, 29)
        Me.btnRuta.TabIndex = 11
        Me.btnRuta.Text = "RUTA BD"
        Me.btnRuta.UseVisualStyleBackColor = False
        '
        'txtRuta
        '
        Me.txtRuta.Location = New System.Drawing.Point(155, 413)
        Me.txtRuta.Margin = New System.Windows.Forms.Padding(2)
        Me.txtRuta.Multiline = True
        Me.txtRuta.Name = "txtRuta"
        Me.txtRuta.ReadOnly = True
        Me.txtRuta.Size = New System.Drawing.Size(830, 30)
        Me.txtRuta.TabIndex = 13
        '
        'btnConectar
        '
        Me.btnConectar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnConectar.Enabled = False
        Me.btnConectar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConectar.Location = New System.Drawing.Point(38, 462)
        Me.btnConectar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnConectar.Name = "btnConectar"
        Me.btnConectar.Size = New System.Drawing.Size(104, 29)
        Me.btnConectar.TabIndex = 14
        Me.btnConectar.Text = "CONECTAR"
        Me.btnConectar.UseVisualStyleBackColor = False
        '
        'lblResultado
        '
        Me.lblResultado.AutoSize = True
        Me.lblResultado.Location = New System.Drawing.Point(152, 470)
        Me.lblResultado.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblResultado.Name = "lblResultado"
        Me.lblResultado.Size = New System.Drawing.Size(0, 13)
        Me.lblResultado.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(35, 384)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(253, 17)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Seleccione la base de datos a emplear"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Cancionify.My.Resources.Resources.Captura_de_pantalla_2021_04_25_000356
        Me.PictureBox1.Location = New System.Drawing.Point(574, 141)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(402, 82)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 80
        Me.PictureBox1.TabStop = False
        '
        'frmEntrar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Azure
        Me.ClientSize = New System.Drawing.Size(1022, 506)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblResultado)
        Me.Controls.Add(Me.btnConectar)
        Me.Controls.Add(Me.txtRuta)
        Me.Controls.Add(Me.btnRuta)
        Me.Controls.Add(Me.grpEntrar)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmEntrar"
        Me.Text = "ACCESO A LA APLICACIÓN"
        Me.grpEntrar.ResumeLayout(False)
        Me.grpEntrar.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpEntrar As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents listaEmail As ListBox
    Friend WithEvents btnModificarUsuarios As Button
    Friend WithEvents btnRuta As Button
    Friend WithEvents txtRuta As TextBox
    Friend WithEvents btnConectar As Button
    Friend WithEvents lblResultado As Label



    Friend WithEvents btnEntrar As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents odfRuta As OpenFileDialog
    Friend WithEvents listConsulta4 As ListBox
    Friend WithEvents btnConsulta4 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents btnConsulta5 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents lblConsulta5 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
