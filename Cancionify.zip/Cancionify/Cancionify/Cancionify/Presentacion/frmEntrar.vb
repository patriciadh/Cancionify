﻿Imports System.Globalization

Public Class frmEntrar
    Public Sub btnConectar_Click(sender As Object, e As EventArgs) Handles btnConectar.Click
        Dim Uaux As Usuario = New Usuario

        Try
            Uaux.LeerTodosUsuarios(txtRuta.Text)

        Catch ex As Exception

            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            lblResultado.Text = "Error de conexión"
            lblResultado.ForeColor = Color.Red
            Exit Sub
        End Try

        For Each Us As Usuario In Uaux.UsuDAO.Usuarios
            listaEmail.Items.Add(Us.Email)
        Next
        btnRuta.Enabled = False
        btnConectar.Enabled = False
        grpEntrar.Enabled = True
        lblResultado.Text = "Conexion Ok"
        lblResultado.ForeColor = Color.Green
        btnModificarUsuarios.Enabled = False

    End Sub

    Public Sub btnRuta_Click(sender As Object, e As EventArgs) Handles btnRuta.Click
        odfRuta.InitialDirectory = Application.StartupPath
        If odfRuta.ShowDialog() = DialogResult.OK Then
            txtRuta.Text = odfRuta.FileName
            btnConectar.Enabled = True
        End If
    End Sub
    Public Sub lista_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaEmail.SelectedIndexChanged
        Dim Uaux As Usuario
        If listaEmail.SelectedItem IsNot Nothing Then
            Uaux = New Usuario(listaEmail.SelectedItem.ToString())
            Try
                Uaux.LeerUsuario()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub

            End Try

            btnModificarUsuarios.Enabled = True
            btnEntrar.Enabled = True
            btnModificarUsuarios.Enabled = True
            btnConsulta4.Enabled = True
            btnConsulta5.Enabled = True
        End If
    End Sub

    Public Sub btnEntrar_Click(sender As Object, e As EventArgs) Handles btnEntrar.Click
        Dim artista As frmArtista = New frmArtista
        Me.Hide()
        artista.Show()
    End Sub

    Public Sub btnModificarUsuarios_Click(sender As Object, e As EventArgs) Handles btnModificarUsuarios.Click
        Me.Hide()
        frmRegistrar.Show()
    End Sub

    ' CONSULTA 4
    Private Sub btnConsulta4_Click(sender As Object, e As EventArgs) Handles btnConsulta4.Click

        Dim usuario As New Usuario(listaEmail.SelectedItem.ToString)

        usuario.LeerUsuario()

        usuario.Consulta4()

        listConsulta4.Items.Clear()

        For Each con4 As String In usuario.UsuDAO.Usuarios
            listConsulta4.Items.Add(con4)
        Next
    End Sub

    ' CONSULTA 5
    Private Sub btnConsulta5_Click(sender As Object, e As EventArgs) Handles btnConsulta5.Click
        Dim usuario As New Usuario(listaEmail.SelectedItem.ToString)
        usuario.LeerUsuario()
        usuario.Consulta5()

        For Each con5 As String In usuario.UsuDAO.Usuarios

            Dim mHours As Long, mMinutes As Long, mSeconds As Long

            If con5 = Nothing Then
                mHours = 0
                mMinutes = 0
                mSeconds = 0
            Else
                mSeconds = Convert.ToInt32(con5)
                mHours = mSeconds \ 3600
                mMinutes = (mSeconds - (mHours * 3600)) \ 60
                mSeconds = mSeconds - ((mHours * 3600) + (mMinutes * 60))
            End If

            lblConsulta5.Text = (mHours & ":" & mMinutes & ":" & mSeconds)
        Next

    End Sub

End Class