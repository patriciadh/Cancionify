﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRegistrar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.btnmodificar = New System.Windows.Forms.Button()
        Me.btnAñadir = New System.Windows.Forms.Button()
        Me.grpModificarUsuarios = New System.Windows.Forms.GroupBox()
        Me.btnAtras = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtNombre = New System.Windows.Forms.TextBox()
        Me.txtApellidos = New System.Windows.Forms.TextBox()
        Me.txtFechaNac = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblFechaNac = New System.Windows.Forms.Label()
        Me.lblApellidos = New System.Windows.Forms.Label()
        Me.lblNombre = New System.Windows.Forms.Label()
        Me.listaEmail = New System.Windows.Forms.ListBox()
        Me.grpModificarUsuarios.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnLimpiar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimpiar.Location = New System.Drawing.Point(487, 416)
        Me.btnLimpiar.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(493, 54)
        Me.btnLimpiar.TabIndex = 9
        Me.btnLimpiar.Text = "LIMPIAR"
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'btnEliminar
        '
        Me.btnEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnEliminar.Enabled = False
        Me.btnEliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEliminar.Location = New System.Drawing.Point(811, 279)
        Me.btnEliminar.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(169, 54)
        Me.btnEliminar.TabIndex = 8
        Me.btnEliminar.Text = "ELIMINAR"
        Me.btnEliminar.UseVisualStyleBackColor = False
        '
        'btnmodificar
        '
        Me.btnmodificar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnmodificar.Enabled = False
        Me.btnmodificar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmodificar.Location = New System.Drawing.Point(811, 133)
        Me.btnmodificar.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.btnmodificar.Name = "btnmodificar"
        Me.btnmodificar.Size = New System.Drawing.Size(169, 54)
        Me.btnmodificar.TabIndex = 7
        Me.btnmodificar.Text = "MODIFICAR"
        Me.btnmodificar.UseVisualStyleBackColor = False
        '
        'btnAñadir
        '
        Me.btnAñadir.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnAñadir.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAñadir.Location = New System.Drawing.Point(811, 203)
        Me.btnAñadir.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.btnAñadir.Name = "btnAñadir"
        Me.btnAñadir.Size = New System.Drawing.Size(169, 54)
        Me.btnAñadir.TabIndex = 6
        Me.btnAñadir.Text = "AÑADIR"
        Me.btnAñadir.UseVisualStyleBackColor = False
        '
        'grpModificarUsuarios
        '
        Me.grpModificarUsuarios.BackColor = System.Drawing.Color.LightCyan
        Me.grpModificarUsuarios.Controls.Add(Me.btnAtras)
        Me.grpModificarUsuarios.Controls.Add(Me.Label2)
        Me.grpModificarUsuarios.Controls.Add(Me.Label1)
        Me.grpModificarUsuarios.Controls.Add(Me.txtNombre)
        Me.grpModificarUsuarios.Controls.Add(Me.txtApellidos)
        Me.grpModificarUsuarios.Controls.Add(Me.txtFechaNac)
        Me.grpModificarUsuarios.Controls.Add(Me.txtEmail)
        Me.grpModificarUsuarios.Controls.Add(Me.lblEmail)
        Me.grpModificarUsuarios.Controls.Add(Me.lblFechaNac)
        Me.grpModificarUsuarios.Controls.Add(Me.lblApellidos)
        Me.grpModificarUsuarios.Controls.Add(Me.lblNombre)
        Me.grpModificarUsuarios.Controls.Add(Me.listaEmail)
        Me.grpModificarUsuarios.Controls.Add(Me.btnAñadir)
        Me.grpModificarUsuarios.Controls.Add(Me.btnmodificar)
        Me.grpModificarUsuarios.Controls.Add(Me.btnEliminar)
        Me.grpModificarUsuarios.Controls.Add(Me.btnLimpiar)
        Me.grpModificarUsuarios.Location = New System.Drawing.Point(17, 15)
        Me.grpModificarUsuarios.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.grpModificarUsuarios.Name = "grpModificarUsuarios"
        Me.grpModificarUsuarios.Padding = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.grpModificarUsuarios.Size = New System.Drawing.Size(1003, 561)
        Me.grpModificarUsuarios.TabIndex = 2
        Me.grpModificarUsuarios.TabStop = False
        Me.grpModificarUsuarios.Text = "MODIFICAR USUARIOS"
        '
        'btnAtras
        '
        Me.btnAtras.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAtras.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAtras.Location = New System.Drawing.Point(15, 506)
        Me.btnAtras.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.btnAtras.Name = "btnAtras"
        Me.btnAtras.Size = New System.Drawing.Size(111, 38)
        Me.btnAtras.TabIndex = 46
        Me.btnAtras.Text = "ATRÁS"
        Me.btnAtras.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(7, 42)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(440, 17)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Para modificar o eliminar un usuario, seleccione un e-mail de la lista:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(484, 79)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(248, 17)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Introduzca aquí sus datos personales:"
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(492, 149)
        Me.txtNombre.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(285, 23)
        Me.txtNombre.TabIndex = 18
        '
        'txtApellidos
        '
        Me.txtApellidos.Location = New System.Drawing.Point(492, 219)
        Me.txtApellidos.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.txtApellidos.Name = "txtApellidos"
        Me.txtApellidos.Size = New System.Drawing.Size(285, 23)
        Me.txtApellidos.TabIndex = 17
        '
        'txtFechaNac
        '
        Me.txtFechaNac.Location = New System.Drawing.Point(492, 295)
        Me.txtFechaNac.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.txtFechaNac.Name = "txtFechaNac"
        Me.txtFechaNac.Size = New System.Drawing.Size(285, 23)
        Me.txtFechaNac.TabIndex = 16
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(492, 365)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(488, 23)
        Me.txtEmail.TabIndex = 15
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(484, 342)
        Me.lblEmail.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(48, 13)
        Me.lblEmail.TabIndex = 14
        Me.lblEmail.Text = "E-MAIL"
        '
        'lblFechaNac
        '
        Me.lblFechaNac.AutoSize = True
        Me.lblFechaNac.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFechaNac.Location = New System.Drawing.Point(487, 268)
        Me.lblFechaNac.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFechaNac.Name = "lblFechaNac"
        Me.lblFechaNac.Size = New System.Drawing.Size(149, 13)
        Me.lblFechaNac.TabIndex = 13
        Me.lblFechaNac.Text = "FECHA DE NACIMIENTO"
        '
        'lblApellidos
        '
        Me.lblApellidos.AutoSize = True
        Me.lblApellidos.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblApellidos.Location = New System.Drawing.Point(487, 196)
        Me.lblApellidos.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblApellidos.Name = "lblApellidos"
        Me.lblApellidos.Size = New System.Drawing.Size(75, 13)
        Me.lblApellidos.TabIndex = 12
        Me.lblApellidos.Text = "APELLIDOS"
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombre.Location = New System.Drawing.Point(487, 125)
        Me.lblNombre.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(60, 13)
        Me.lblNombre.TabIndex = 11
        Me.lblNombre.Text = "NOMBRE"
        '
        'listaEmail
        '
        Me.listaEmail.FormattingEnabled = True
        Me.listaEmail.ItemHeight = 16
        Me.listaEmail.Location = New System.Drawing.Point(15, 82)
        Me.listaEmail.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.listaEmail.Name = "listaEmail"
        Me.listaEmail.Size = New System.Drawing.Size(432, 388)
        Me.listaEmail.TabIndex = 10
        '
        'frmRegistrar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Aquamarine
        Me.ClientSize = New System.Drawing.Size(1032, 588)
        Me.Controls.Add(Me.grpModificarUsuarios)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.Name = "frmRegistrar"
        Me.Text = "MODIFICAR USUARIO"
        Me.grpModificarUsuarios.ResumeLayout(False)
        Me.grpModificarUsuarios.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnmodificar As Button
    Friend WithEvents btnAñadir As Button
    Friend WithEvents grpModificarUsuarios As GroupBox
    Friend WithEvents listaEmail As ListBox
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtApellidos As TextBox
    Friend WithEvents txtFechaNac As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents lblEmail As Label
    Friend WithEvents lblFechaNac As Label
    Friend WithEvents lblApellidos As Label
    Friend WithEvents lblNombre As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnAtras As Button
End Class
