﻿Public Class frmRegistrar
    Public Sub frmRegistrar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Raux As Usuario = New Usuario
        Raux.LeerTodosUsuarios(frmEntrar.txtRuta.Text)
        For Each Us As Usuario In Raux.UsuDAO.Usuarios
            listaEmail.Items.Add(Us.Email)
        Next
    End Sub

    Public Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        Dim Uaux As Usuario
        If txtEmail.Text IsNot String.Empty And txtNombre.Text IsNot String.Empty And txtApellidos.Text IsNot String.Empty And txtFechaNac.Text IsNot String.Empty Then

            Try
                Uaux = New Usuario(txtEmail.Text)
                Uaux.Nombre = txtNombre.Text
                Uaux.Apellidos = txtApellidos.Text
                Uaux.FechaNac = txtFechaNac.Text
                If Uaux.ActualizarUsuario() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaEmail.Update()
                    MessageBox.Show("Nombre para" & Uaux.Email & " actualizado correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
    Public Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Dim UsuarioAUx As Usuario
        If txtEmail.Text IsNot String.Empty And txtNombre.Text IsNot String.Empty And txtApellidos.Text IsNot String.Empty And txtFechaNac.Text IsNot String.Empty Then
            UsuarioAUx = New Usuario(txtEmail.Text)
            UsuarioAUx.Nombre = txtNombre.Text
            UsuarioAUx.Apellidos = txtApellidos.Text
            UsuarioAUx.FechaNac = txtFechaNac.Text
            Try
                If UsuarioAUx.BorrarUsuario() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    listaEmail.Items.Remove(UsuarioAUx.Email)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
    Public Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtNombre.Text = String.Empty
        txtEmail.Text = String.Empty
        txtApellidos.Text = String.Empty
        txtFechaNac.Text = String.Empty
        btnmodificar.Enabled = False
        btnEliminar.Enabled = False
        btnAñadir.Enabled = True
    End Sub

    Public Sub btnAñadir_Click(sender As Object, e As EventArgs) Handles btnAñadir.Click
        Dim UsuarioAux As New Usuario
        If txtEmail.Text IsNot String.Empty And txtNombre.Text IsNot String.Empty And txtApellidos.Text IsNot String.Empty And txtFechaNac.Text IsNot String.Empty Then
            Try
                UsuarioAux = New Usuario(txtEmail.Text)
                UsuarioAux.Nombre = txtNombre.Text
                UsuarioAux.Apellidos = txtApellidos.Text
                UsuarioAux.FechaNac = txtFechaNac.Text
                If UsuarioAux.InsertarUsuario() <> 1 Then
                    MessageBox.Show("Insert <> 1 ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    UsuarioAux.LeerTodosUsuarios(frmEntrar.txtRuta.Text)
                    listaEmail.Items.Add(UsuarioAux.Email)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Sub listaEmail_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaEmail.SelectedIndexChanged
        Dim UsuarioAux As Usuario
        If listaEmail.SelectedItem IsNot Nothing Then
            UsuarioAux = New Usuario(listaEmail.SelectedItem.ToString)
            Try
                UsuarioAux.LeerUsuario()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            txtEmail.Text = UsuarioAux.Email
            txtNombre.Text = UsuarioAux.Nombre
            txtApellidos.Text = UsuarioAux.Apellidos
            txtFechaNac.Text = UsuarioAux.FechaNac
            btnmodificar.Enabled = True
            btnEliminar.Enabled = True
            btnAñadir.Enabled = False
        End If
    End Sub

    Public Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Me.Hide()
        frmEntrar.Show()
    End Sub
End Class